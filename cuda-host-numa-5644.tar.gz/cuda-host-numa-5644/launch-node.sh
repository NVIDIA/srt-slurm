#!/bin/bash
set -euo pipefail
run_dir=${1:?Run directory is required}
diagnostic_pid=
cleanup() {
    local rc=$? deadline cleanup_failed=0
    trap - EXIT
    trap '' INT TERM
    set +e
    if [[ -n $diagnostic_pid ]]; then
        kill -TERM "$diagnostic_pid" 2>/dev/null || true
        deadline=$((SECONDS + 60))
        while kill -0 "$diagnostic_pid" 2>/dev/null && (( SECONDS < deadline )); do sleep 1; done
        if kill -0 "$diagnostic_pid" 2>/dev/null; then
            printf 'Diagnostic did not stop within 60 seconds; killing owned PID %s.\n' "$diagnostic_pid" >&2
            kill -KILL "$diagnostic_pid" 2>/dev/null || true
            cleanup_failed=1
        fi
        wait "$diagnostic_pid" 2>/dev/null
    fi
    timeout --signal=TERM --kill-after=2s 15s \
        python3 "$run_dir/tools/cuda_host_numa_probe.py" inventory --output "$run_dir/logs/container-after.json" \
        >> "$run_dir/logs/container-inventory-errors.log" 2>&1
    timeout --signal=TERM --kill-after=2s 5s dmesg --ctime > "$run_dir/logs/kernel-after.txt" 2>&1
    if (( cleanup_failed != 0 && rc == 0 )); then rc=1; fi
    printf 'exit_code=%s cleanup_failed=%s\n' "$rc" "$cleanup_failed" > "$run_dir/logs/shutdown.txt"
    exit "$rc"
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM

# Remove inherited MPI launch state; preserve allocation/cgroup evidence.
for name in $(compgen -e); do
    case "$name" in PMIX_*|PMI_*|OMPI_*|MPI_*|OPAL_*|PRTE_*|HYDRA_*|I_MPI_*) unset "$name" ;; esac
done
export CUDA_VISIBLE_DEVICES=0,1,2,3
export PYTHONUNBUFFERED=1
{
    hostname
    timeout --signal=TERM --kill-after=2s 10s \
        nvidia-smi --query-gpu=index,uuid,pci.bus_id,name,memory.total,driver_version --format=csv || true
    timeout --signal=TERM --kill-after=2s 10s nvidia-smi topo -m || true
    timeout --signal=TERM --kill-after=2s 10s nvidia-smi -q || true
    if command -v numactl >/dev/null; then timeout --signal=TERM --kill-after=2s 5s numactl --hardware || true; fi
    ls -l /dev/nvidia-caps-imex-channels/ || true
} > "$run_dir/logs/container-hardware.txt" 2>&1
timeout --signal=TERM --kill-after=2s 5s dmesg --ctime > "$run_dir/logs/kernel-before.txt" 2>&1 || true
timeout --signal=TERM --kill-after=2s 15s \
    python3 "$run_dir/tools/cuda_host_numa_probe.py" inventory --output "$run_dir/logs/container-before.json" \
    > "$run_dir/logs/container-inventory-errors.log" 2>&1 || \
    printf 'Container inventory failed; see container-inventory-errors.log.\n' >&2

build() {
    local compiler=${CUDA_EGM_CXX:-g++} cuda_home=${CUDA_EGM_CUDA_HOME:-/usr/local/cuda}
    local include=${CUDA_EGM_INCLUDE:-} candidate library=${CUDA_EGM_LIBCUDA:-}
    if ! command -v "$compiler" >/dev/null; then
        if [[ -z ${CUDA_EGM_CXX:-} ]] && command -v c++ >/dev/null; then compiler=c++
        else printf 'A C++17 compiler is required; set CUDA_EGM_CXX.\n' >&2; return 2; fi
    fi
    if [[ -z $include ]]; then
        for candidate in "$cuda_home/include" "$cuda_home/targets/$(uname -m)-linux/include" /usr/local/cuda*/include; do
            if [[ -f $candidate/cuda.h ]]; then include=$candidate; break; fi
        done
    fi
    if [[ -z $include || ! -f $include/cuda.h ]]; then
        printf 'CUDA 12.9+ driver headers are required (CUDA 13 preferred); set CUDA_EGM_INCLUDE or CUDA_EGM_CUDA_HOME.\n' >&2
        return 2
    fi
    if [[ -z $library ]]; then
        for candidate in /usr/lib/"$(uname -m)"-linux-gnu/libcuda.so.1 /usr/lib64/libcuda.so.1 \
                         /usr/local/nvidia/lib64/libcuda.so.1 /usr/local/nvidia/lib/libcuda.so.1 \
                         "$cuda_home/lib64/stubs/libcuda.so" "$cuda_home/targets/$(uname -m)-linux/lib/stubs/libcuda.so"; do
            if [[ -f $candidate ]]; then library=$candidate; break; fi
        done
    fi
    local command=("$compiler" -std=c++17 -O2 -Wall -Wextra -I "$include" \
        "$run_dir/tools/cuda_host_numa_repro.cpp" -o "$run_dir/cuda_host_numa_repro")
    if [[ -n $library ]]; then command+=("$library"); else command+=(-lcuda); fi
    "$compiler" --version
    printf 'CUDA headers: %s\nCompiler command:' "$include"
    printf ' %q' "${command[@]}"
    printf '\n'
    python3 - "$run_dir/logs/build.json" "${command[@]}" <<'PY'
import json
import sys
from pathlib import Path

Path(sys.argv[1]).write_text(json.dumps({"argv": sys.argv[2:]}, indent=2) + "\n")
PY
    # CUDA stubs, when used, are link-only. Never add stubs to the runtime library path.
    timeout --signal=TERM --kill-after=5s "${CUDA_EGM_BUILD_TIMEOUT}s" "${command[@]}"
    timeout 5s ldd "$run_dir/cuda_host_numa_repro"
    timeout 5s "$run_dir/cuda_host_numa_repro" --help
}
build > "$run_dir/logs/build.log" 2>&1
diagnostic_rc=0
# A completed CUDA allocation failure is evidence. Timeouts/incomplete cleanup fail the job.
timeout --signal=TERM --kill-after=45s "$((CUDA_EGM_BUDGET + 30))s" \
    python3 "$run_dir/tools/cuda_host_numa_probe.py" run \
    --binary "$run_dir/cuda_host_numa_repro" --output-dir "$run_dir/logs/probe" \
    --size "$CUDA_EGM_SIZE" --cases "$CUDA_EGM_CASES" \
    --allocation-timeout "$CUDA_EGM_ALLOCATION_TIMEOUT" --budget "$CUDA_EGM_BUDGET" \
    --sample-interval "$CUDA_EGM_SAMPLE_INTERVAL" --hold-seconds "$CUDA_EGM_HOLD_SECONDS" \
    --chunk-size "$CUDA_EGM_CHUNK_SIZE" > "$run_dir/logs/probe.log" 2>&1 &
diagnostic_pid=$!
wait "$diagnostic_pid" || diagnostic_rc=$?
diagnostic_pid=
printf 'CUDA allocation diagnostic helper exit code: %s\n' "$diagnostic_rc"
exit "$diagnostic_rc"
