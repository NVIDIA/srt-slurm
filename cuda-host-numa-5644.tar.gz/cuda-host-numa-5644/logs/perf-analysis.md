# CUDA HOST_NUMA allocation investigation

Diagnostic: **COMPLETE**; launcher exit code `0`.

Completion means observations and cleanup finished; controlled allocation OOM is an outcome, not a successful allocation.

Node: `vr-r41-cn15`. Window: `2026-10-22T17:59:13.958537+00:00` to `2026-10-22T17:59:45.832814+00:00`. Requested bytes per rank: `268435456000`.

Goal: isolate the native CUDA backing allocation with the first handle still resident when the second process calls cuMemCreate. The C++ executable uses PINNED, explicit HOST_NUMA and FABRIC properties, queries minimum granularity, and retains successful handles until directed to call cuMemRelease. It uses no serving framework or GPU payload allocations.

| Case | Observation | Held GiB at result, by rank | Completion / failure |
| --- | --- | --- | --- |
| [same-numa](probe/same-numa/trial.json) | second_allocation_oom | GPU 0 / NUMA 0: 250.000; GPU 1 / NUMA 0: 0.000 | complete; none |
| [cross-numa](probe/cross-numa/trial.json) | two_allocations_succeeded | GPU 0 / NUMA 0: 250.000; GPU 2 / NUMA 1: 250.000 | complete; none |
| [reverse-gpu](probe/reverse-gpu/trial.json) | second_allocation_oom | GPU 1 / NUMA 0: 250.000; GPU 0 / NUMA 0: 0.000 | complete; none |
| [chunked](probe/chunked/trial.json) | second_allocation_oom | GPU 0 / NUMA 0: 250.000; GPU 1 / NUMA 0: 203.125 | complete; none |

## NUMA memory around allocations

GiB below come from node meminfo. The second-result snapshot holds partial allocations after a failed create, before releasing either process's handles. Serial cases can warm driver caches; compare their baselines.

| Case | Stage | NUMA | Free GiB | FilePages GiB | KReclaimable GiB |
| --- | --- | --- | ---: | ---: | ---: |
| same-numa | [after-release](probe/same-numa/after-release.json) | 0 | 8.444 | 217.095 | 469.329 |
| same-numa | [after-release](probe/same-numa/after-release.json) | 1 | 15.249 | 234.739 | 448.387 |
| same-numa | [baseline](probe/same-numa/baseline.json) | 0 | 5.799 | 220.992 | 467.393 |
| same-numa | [baseline](probe/same-numa/baseline.json) | 1 | 15.059 | 234.739 | 448.387 |
| same-numa | [before-first](probe/same-numa/before-first.json) | 0 | 5.799 | 220.992 | 467.393 |
| same-numa | [before-first](probe/same-numa/before-first.json) | 1 | 15.059 | 234.739 | 448.387 |
| same-numa | [before-second](probe/same-numa/before-second.json) | 0 | 5.676 | 220.993 | 217.368 |
| same-numa | [before-second](probe/same-numa/before-second.json) | 1 | 14.052 | 234.739 | 448.387 |
| same-numa | [first-result](probe/same-numa/first-result.json) | 0 | 5.677 | 220.993 | 217.368 |
| same-numa | [first-result](probe/same-numa/first-result.json) | 1 | 14.059 | 234.739 | 448.387 |
| same-numa | [second-result](probe/same-numa/second-result.json) | 0 | 8.493 | 217.094 | 219.279 |
| same-numa | [second-result](probe/same-numa/second-result.json) | 1 | 14.242 | 234.739 | 448.387 |
| cross-numa | [after-release](probe/cross-numa/after-release.json) | 0 | 8.417 | 217.099 | 469.322 |
| cross-numa | [after-release](probe/cross-numa/after-release.json) | 1 | 15.226 | 234.739 | 448.387 |
| cross-numa | [baseline](probe/cross-numa/baseline.json) | 0 | 8.444 | 217.095 | 469.329 |
| cross-numa | [baseline](probe/cross-numa/baseline.json) | 1 | 15.249 | 234.739 | 448.387 |
| cross-numa | [before-first](probe/cross-numa/before-first.json) | 0 | 8.442 | 217.095 | 469.329 |
| cross-numa | [before-first](probe/cross-numa/before-first.json) | 1 | 15.249 | 234.739 | 448.387 |
| cross-numa | [before-second](probe/cross-numa/before-second.json) | 0 | 8.330 | 217.097 | 219.304 |
| cross-numa | [before-second](probe/cross-numa/before-second.json) | 1 | 14.214 | 234.739 | 448.387 |
| cross-numa | [first-result](probe/cross-numa/first-result.json) | 0 | 8.330 | 217.097 | 219.304 |
| cross-numa | [first-result](probe/cross-numa/first-result.json) | 1 | 14.214 | 234.739 | 448.387 |
| cross-numa | [second-result](probe/cross-numa/second-result.json) | 0 | 8.274 | 217.098 | 219.279 |
| cross-numa | [second-result](probe/cross-numa/second-result.json) | 1 | 13.133 | 234.739 | 198.387 |
| reverse-gpu | [after-release](probe/reverse-gpu/after-release.json) | 0 | 10.099 | 215.546 | 469.403 |
| reverse-gpu | [after-release](probe/reverse-gpu/after-release.json) | 1 | 15.241 | 234.739 | 448.387 |
| reverse-gpu | [baseline](probe/reverse-gpu/baseline.json) | 0 | 8.416 | 217.099 | 469.322 |
| reverse-gpu | [baseline](probe/reverse-gpu/baseline.json) | 1 | 15.226 | 234.739 | 448.387 |
| reverse-gpu | [before-first](probe/reverse-gpu/before-first.json) | 0 | 8.416 | 217.099 | 469.322 |
| reverse-gpu | [before-first](probe/reverse-gpu/before-first.json) | 1 | 15.226 | 234.739 | 448.387 |
| reverse-gpu | [before-second](probe/reverse-gpu/before-second.json) | 0 | 8.317 | 217.101 | 219.304 |
| reverse-gpu | [before-second](probe/reverse-gpu/before-second.json) | 1 | 14.188 | 234.739 | 448.387 |
| reverse-gpu | [first-result](probe/reverse-gpu/first-result.json) | 0 | 8.317 | 217.101 | 219.304 |
| reverse-gpu | [first-result](probe/reverse-gpu/first-result.json) | 1 | 14.188 | 234.739 | 448.387 |
| reverse-gpu | [second-result](probe/reverse-gpu/second-result.json) | 0 | 9.999 | 215.551 | 219.354 |
| reverse-gpu | [second-result](probe/reverse-gpu/second-result.json) | 1 | 14.197 | 234.739 | 448.387 |
| chunked | [after-release](probe/chunked/after-release.json) | 0 | 11.937 | 213.471 | 469.432 |
| chunked | [after-release](probe/chunked/after-release.json) | 1 | 15.246 | 234.739 | 448.387 |
| chunked | [baseline](probe/chunked/baseline.json) | 0 | 10.097 | 215.546 | 469.403 |
| chunked | [baseline](probe/chunked/baseline.json) | 1 | 15.241 | 234.739 | 448.387 |
| chunked | [before-first](probe/chunked/before-first.json) | 0 | 10.097 | 215.546 | 469.403 |
| chunked | [before-first](probe/chunked/before-first.json) | 1 | 15.241 | 234.739 | 448.387 |
| chunked | [before-second](probe/chunked/before-second.json) | 0 | 9.800 | 215.548 | 219.378 |
| chunked | [before-second](probe/chunked/before-second.json) | 1 | 14.307 | 234.739 | 448.387 |
| chunked | [first-result](probe/chunked/first-result.json) | 0 | 9.801 | 215.548 | 219.378 |
| chunked | [first-result](probe/chunked/first-result.json) | 1 | 14.307 | 234.739 | 448.387 |
| chunked | [second-result](probe/chunked/second-result.json) | 0 | 11.866 | 213.470 | 16.264 |
| chunked | [second-result](probe/chunked/second-result.json) | 1 | 13.456 | 234.739 | 448.387 |

## Second-allocation reclaim and cgroup evidence

Deltas cover before-second to second-result, while both processes retain their handles. Global VM counters can include background activity. Detailed counters, cgroup usage/limits/events and missing paths are saved in [counter-analysis.json](counter-analysis.json). Unavailable observations are not treated as zero activity.

| Case | Reclaim/compaction counter deltas | Cgroup event deltas | NVIDIA shrinker view |
| --- | --- | --- | --- |
| same-numa | allocstall_normal=+7, pgsteal_kswapd=+63436, pgsteal_direct=+475, pgscan_kswapd=+63436, pgscan_direct=+475, pgscan_file=+63911, pgsteal_file=+63911, compact_migrate_scanned=+32938, compact_free_scanned=+158714, compact_isolated=+6, compact_stall=+8, compact_fail=+8, compact_daemon_wake=+336, compact_daemon_migrate_scanned=+32938, compact_daemon_free_scanned=+158714 | `/sys/fs/cgroup`: {"high": 0, "low": 0, "max": 0, "oom": 0, "oom_group_kill": 0, "oom_kill": 0, "sock_throttled": 0} | unavailable; FileNotFoundError: [Errno 2] No such file or directory: '/sys/kernel/debug/shrinker' |
| cross-numa | compact_migrate_scanned=+32768, compact_free_scanned=+130597, compact_isolated=+4, compact_daemon_wake=+6, compact_daemon_migrate_scanned=+32768, compact_daemon_free_scanned=+130597 | `/sys/fs/cgroup`: {"high": 0, "low": 0, "max": 0, "oom": 0, "oom_group_kill": 0, "oom_kill": 0, "sock_throttled": 0} | unavailable; FileNotFoundError: [Errno 2] No such file or directory: '/sys/kernel/debug/shrinker' |
| reverse-gpu | allocstall_normal=+1, pgsteal_kswapd=+25455, pgsteal_direct=+64, pgscan_kswapd=+25455, pgscan_direct=+64, pgscan_file=+25519, pgsteal_file=+25519, compact_migrate_scanned=+5668898, compact_free_scanned=+548793, compact_isolated=+47276, compact_stall=+2, compact_fail=+2, compact_daemon_wake=+9, compact_daemon_migrate_scanned=+5668898, compact_daemon_free_scanned=+548793 | `/sys/fs/cgroup`: {"high": 0, "low": 0, "max": 0, "oom": 0, "oom_group_kill": 0, "oom_kill": 0, "sock_throttled": 0} | unavailable; FileNotFoundError: [Errno 2] No such file or directory: '/sys/kernel/debug/shrinker' |
| chunked | allocstall_normal=+7, pgsteal_kswapd=+33607, pgsteal_direct=+458, pgscan_kswapd=+33607, pgscan_direct=+458, pgscan_file=+34065, pgsteal_file=+34065, compact_migrate_scanned=+32768, compact_free_scanned=+130597, compact_isolated=+4, compact_stall=+8, compact_fail=+8, compact_daemon_migrate_scanned=+32768, compact_daemon_free_scanned=+130597 | `/sys/fs/cgroup`: {"high": 0, "low": 0, "max": 0, "oom": 0, "oom_group_kill": 0, "oom_kill": 0, "sock_throttled": 0} | unavailable; FileNotFoundError: [Errno 2] No such file or directory: '/sys/kernel/debug/shrinker' |

## Interpretation and evidence

A failure following the second allocation on NUMA0, with successful allocations across nodes and GPU order reversed, supports NUMA-local allocation constraints. Smaller chunks can show partial resident capacity, but API chunk size does not establish the driver's page order or a physically contiguous full-pool requirement. Inspect each native rank log/JSON for failed_api, failed_result, exact error names, granularity and GPU identity.

The snapshots/samples retain /proc/vmstat reclaim/compaction counters, buddyinfo, node meminfo/vmstat, actual child cgroup membership, visible ancestor memory limits/events, driver parameters, page size and read-only NVIDIA shrinker counts. Unavailable paths and permission errors are evidence gaps, not zero counters or empty pools. Check kernel-before/after logs when accessible; no privileged operation or cache eviction is attempted.

This creation-only experiment stops before VA mapping, Fabric handle export/import and NVLink copies. If the direct API reproduces OOM, the failure is independent of the serving stack; if it succeeds, the original failure is not reproduced and context/mapping/lifetime or changed node state may matter. A cached allocation released successfully need not immediately appear as Linux free memory.

## Required serving metrics

| Metric | Value | Reason |
| --- | --- | --- |
| TTFT p50/p95/p99 (ms) | N/A | No inference requests |
| ITL p50/p99 (ms/token) | N/A | No generated tokens |
| Output/input/total throughput (tokens/s) | N/A | Allocation-only workload |
| Agentic Pareto/SLO, goodput, concurrency | N/A | No agentic workload |
| Transfer bandwidth/latency | N/A | No payload transfers |

## Sources and collection

- [Summary](probe/summary.json), per-case trial/rank JSON, native rank logs, phase snapshots and samples.jsonl: connect actual CUDA calls and resident handles to memory state and cleanup.
- [Launch metadata](launch.json), Slurm/hardware/compiler/kernel logs and archived C++/Python/batch sources: identify the environment and make the experiment reproducible without the serving repository.
- The slurm-job-sizing skill sets a bounded 20-minute allocation investigation; no serving warmup or traffic is needed. No DSight/dashboard skill is used because native allocation calls and memory evidence answer this goal.
- [CUDA Driver API VMM documentation](https://docs.nvidia.com/cuda/archive/13.0.3/cuda-driver-api/group__CUDA__VA.html): defines HOST_NUMA, FABRIC, allocation granularity and cuMemCreate/cuMemRelease.

Batch exit code: 0.
