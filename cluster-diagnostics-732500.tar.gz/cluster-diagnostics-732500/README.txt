Host/container hardware checks and sequential copies reuse the existing collector.
performance.json describes an idle collector, not a serving worker. For serving
placement, run the Python collect command with actual worker PIDs inside their container.
communication.json records rank environments/placement and MPI timings, optionally NCCL.
Raplab communication ranks use recipe settings recorded in settings.txt; Hecate
inherits transport settings. The NUMA wrapper filters UCX_NET_DEVICES by GPU NUMA.
No serving processes are launched. Missing commands/counters are unknown, not zero errors.
Check all phase exit-status files, per-node COMPLETE markers, copy exit-status/stderr,
and container-setup.txt. Package installation is disabled unless INSTALL_TOOLS=1.
See docs/cluster-performance-diagnostics.md for comparisons and interpretation limits.
