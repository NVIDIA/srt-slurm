# Mooncake remote EGM diagnostic

Host-transfer status: **PASS**; launcher exit code: `0`.
Allocation diagnostic status: **PASSED**. A small-pool transfer pass does not validate recipe-sized pool allocation; see the independent allocation cases below.
Native NVLink memcpy log observed: `True` (source: `client.log`).
Requested verified samples complete: `True` (source: `client-results.json`).
Pinned host source/destination buffers verified: `True` (source: `client-results.json` CUDA pointer attributes).
Report generated: 2026-10-22T15:52:46.065150+00:00.

## Goal and controls

Test whether pinned host buffers can put/get and fully verify data in the other node's EGM host-memory Store pool using the explicitly selected Mooncake NVLink transport. The client owns zero global Store capacity and zero internal Store local-buffer capacity. Each returned replica must be COMPLETE memory on the provider node. Both client payload buffers are pinned CPU tensors and must have CUDA pointer type `cudaMemoryTypeHost`; managed and GPU payload buffers are rejected. GPU IDs select CUDA submission devices only. CUDA contexts, streams and mapping metadata may still use GPU resources; this test does not require zero driver/context HBM consumption.

Baseline: none; this reduced correctness diagnostic does not compare transports or enforce a bandwidth SLO. The small payload sweep measures synchronous API latency, including RPC/control overhead; it does not measure NVLink saturation. No RDMA/TCP data transport is requested. TCP control-plane RPC is still used.

## Configuration and hardware

- Slurm job: `5625`; two allocated nodes.
- Client: `vr-r41-cn03`; provider: `vr-r41-cn01`.
- CUDA submission GPU IDs/names: `[0, 1, 2, 3]` / `{'0': 'NVIDIA Graphics Device', '1': 'NVIDIA Graphics Device', '2': 'NVIDIA Graphics Device', '3': 'NVIDIA Graphics Device'}`.
- Payload allocation: `pinned_host`; verified buffer records: `8` / `8`.
- PyTorch/CUDA: `2.14.0a0+4fdf77b940.nvinternal.rubin.0.8dev` / `13.5`; wheel packages: `{'mooncake-transfer-engine-cuda13': '0.3.14.dev20261021'}`.
- Payload sizes (B): `[65536, 1048576, 16777216, 67108864]`; concurrency: one synchronous transfer; warmup/measurement iterations per GPU/size: `2` / `10`.
- Client window UTC: `2026-10-22T15:52:08.917643+00:00` to `2026-10-22T15:52:22.924741+00:00`; wall duration: `14.002562125999248` s.

## Host-memory allocation diagnostics

Allocation diagnostic status: **PASSED**; collection status: `complete`; provider: `vr-r41-cn01`; CUDA visible devices: `0` (source: [summary.json](allocation-diagnostics/summary.json)).

These probes test native host NUMA/Fabric Store setup and cleanup separately from remote put/get. Their outcomes do not change the remote-transfer status above. CUDA error 2 identifies an allocation or resource failure; it does not identify the limiting resource or establish that GPU payload memory was allocated. Compare host/NUMA availability, cgroup limits and CUDA discovery in the inventory with each case's configuration and errors. Sequential pool successes do not prove that four concurrent pools and inference workers fit.

- [Allocation inventory](allocation-diagnostics/inventory.json): host/NUMA, cgroup and CUDA evidence.

| GPU mask | NUMA nodes | Pool GiB | Case status | Exit code | CUDA errors | Cleanup confirmed | Evidence |
| --- | --- | ---: | --- | --- | --- | --- | --- |
| 0 | 0 | 4 | passed | 0 | none recorded | True | [log](allocation-diagnostics/4294967296-numa-0.log); [result](allocation-diagnostics/4294967296-numa-0.json) |
| 0 | auto | 4 | passed | 0 | none recorded | True | [log](allocation-diagnostics/4294967296-numa-auto.log); [result](allocation-diagnostics/4294967296-numa-auto.json) |
| 0 | 0 | 260 | passed | 0 | none recorded | True | [log](allocation-diagnostics/279172874240-numa-0.log); [result](allocation-diagnostics/279172874240-numa-0.json) |
| 0 | auto | 260 | passed | 0 | none recorded | True | [log](allocation-diagnostics/279172874240-numa-auto.log); [result](allocation-diagnostics/279172874240-numa-auto.json) |

The per-case JSON records native setup/close results, elapsed setup/cleanup time and before/after inventory when available. Missing case results or timeout/cleanup failures leave allocation capacity unproven; they do not by themselves identify the cause. These timings measure allocation probes, not transfer latency or model performance.

## Measurements

TTFT p50/p95/p99 (ms), ITL p50/p99 (ms/token), input/output/total throughput (tokens/s), and agentic Pareto/SLO metrics: **N/A**. This workload transfers bytes and runs no inference requests, model, tokenizer or agentic conversations.

Fully verified transfers: 192 put/get pairs including warmup; 160 measured pairs. Every successful sample compares the complete CPU destination with the deterministic CPU source. Payload generation and equality verification are outside timed intervals.

| GPU | Payload B | API | Samples | p50 ms | p95 ms | p99 ms | Payload GiB/s |
| --- | ---: | --- | ---: | ---: | ---: | ---: | ---: |
| 0 | 65536 | put | 10 | 0.959 | 1.067 | 1.090 | 0.064 |
| 0 | 65536 | get | 10 | 0.495 | 0.542 | 0.552 | 0.124 |
| 0 | 1048576 | put | 10 | 0.962 | 1.028 | 1.039 | 1.024 |
| 0 | 1048576 | get | 10 | 0.506 | 0.535 | 0.543 | 1.981 |
| 0 | 16777216 | put | 10 | 1.461 | 1.632 | 1.646 | 10.797 |
| 0 | 16777216 | get | 10 | 0.648 | 0.794 | 0.816 | 23.599 |
| 0 | 67108864 | put | 10 | 2.382 | 2.697 | 2.721 | 26.110 |
| 0 | 67108864 | get | 10 | 1.498 | 1.619 | 1.629 | 41.414 |
| 1 | 65536 | put | 10 | 0.870 | 1.022 | 1.051 | 0.072 |
| 1 | 65536 | get | 10 | 0.428 | 0.522 | 0.534 | 0.139 |
| 1 | 1048576 | put | 10 | 0.871 | 1.027 | 1.044 | 1.122 |
| 1 | 1048576 | get | 10 | 0.506 | 0.536 | 0.537 | 2.131 |
| 1 | 16777216 | put | 10 | 1.638 | 1.709 | 1.718 | 10.055 |
| 1 | 16777216 | get | 10 | 0.748 | 0.789 | 0.789 | 21.425 |
| 1 | 67108864 | put | 10 | 2.347 | 2.582 | 2.610 | 26.691 |
| 1 | 67108864 | get | 10 | 1.510 | 1.637 | 1.647 | 41.548 |
| 2 | 65536 | put | 10 | 0.896 | 1.048 | 1.058 | 0.068 |
| 2 | 65536 | get | 10 | 0.458 | 0.577 | 0.581 | 0.131 |
| 2 | 1048576 | put | 10 | 0.800 | 0.837 | 0.840 | 1.252 |
| 2 | 1048576 | get | 10 | 0.466 | 0.490 | 0.493 | 2.129 |
| 2 | 16777216 | put | 10 | 1.884 | 2.168 | 2.202 | 8.355 |
| 2 | 16777216 | get | 10 | 1.336 | 1.508 | 1.518 | 11.682 |
| 2 | 67108864 | put | 10 | 3.725 | 4.024 | 4.048 | 16.695 |
| 2 | 67108864 | get | 10 | 3.437 | 3.712 | 3.742 | 17.985 |
| 3 | 65536 | put | 10 | 1.025 | 1.129 | 1.138 | 0.062 |
| 3 | 65536 | get | 10 | 0.549 | 0.575 | 0.578 | 0.118 |
| 3 | 1048576 | put | 10 | 1.009 | 1.098 | 1.103 | 1.001 |
| 3 | 1048576 | get | 10 | 0.557 | 0.617 | 0.618 | 1.820 |
| 3 | 16777216 | put | 10 | 2.019 | 2.265 | 2.287 | 7.764 |
| 3 | 16777216 | get | 10 | 1.345 | 1.361 | 1.362 | 11.943 |
| 3 | 67108864 | put | 10 | 3.600 | 3.737 | 3.747 | 17.505 |
| 3 | 67108864 | get | 10 | 3.600 | 3.717 | 3.736 | 17.380 |

Percentiles use linear interpolation across measured API latency samples. Payload GiB/s is successful payload bytes divided by summed API latency, using 2^30 B/GiB; it excludes warmup.

## Evidence and interpretation

The configured NVLink path completed remote memory put/get operations with full payload verification for every requested submission GPU/size/iteration. CUDA pointer attributes establish pinned host source/destination allocations; replica descriptors prove remote memory placement. The native provider's EGM setup validates HOST_NUMA/Fabric support. This establishes this topology's functional path; it does not qualify TRT-LLM end-to-end behavior or peak throughput.

Client error: `none recorded; inspect launcher logs if incomplete`. Cleanup error: `none recorded`.

- [client-results.json](client-results.json): exact setup, package versions, submission GPU identities, pinned host allocation/pointer-type evidence, timestamps, per-iteration `samples` latencies/verified bytes and replica memory endpoints; raw source for this table.
- [client.log](client.log), [provider.log](provider.log), [master.log](master.log): native setup, HOST_NUMA/Fabric allocation and transport errors. Missing files indicate setup did not reach that phase.
- Inventory/configuration artifacts in this logs directory record node topology, GPU Fabric health, NUMA placement, wheel identity and launch controls; inspect these with the failure logs.
- No DSight report or dashboard was collected: byte-transfer correctness and native replica metadata answer this diagnostic's goal without request traces.
- The [slurm-job-sizing skill](https://github.com/NVIDIA/srt-slurm/blob/main/src/srtctl/dsight/skills/slurm-job-sizing/SKILL.md) guided the short two-node allocation and reduced warmup/payload sweep; see the sbatch script for the whole-job budget. No full inference benchmark or campaign skill was used.
- [Mooncake native source at 042ab8a18b0e](https://github.com/kvcache-ai/Mooncake/tree/042ab8a18b0e6ccfe87782261a5556a3dd4446e4): `mooncake-integration/store/store_py.cpp` supplies the native APIs; `mooncake-transfer-engine/src/transport/nvlink_transport/nvlink_transport.cpp` accepts local host endpoints and copies directly to/from imported Fabric mappings. The descriptor API exposes a memory endpoint, not a transport-protocol or HOST_NUMA field; the transport/EGM evidence comes from strict native setup and logs.
- [CUDA Python 13.0.1 pointer-attribute API](https://nvidia.github.io/cuda-python/cuda-bindings/13.0.1/module/runtime.html#cuda.bindings.runtime.cudaPointerGetAttributes) defines the status/attributes return pair and `cudaMemoryTypeHost` used to verify payload residence.

Batch exit code: 0.
