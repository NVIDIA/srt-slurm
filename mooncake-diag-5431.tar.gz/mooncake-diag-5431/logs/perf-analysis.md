# Mooncake host-memory/RDMA diagnostic

Goal: compare isolated donor placement/capacity under concurrent registered-host-memory reads.
No model or GPU memory pressure is present. This short diagnostic does not reproduce the original roughly 40-minute serving workload.
TTFT p50/p95/p99, ITL p50/p99, token throughput, agentic Pareto/SLO metrics: N/A (host-only byte transfer).

Batch latencies below are milliseconds; percentiles pool completed calls across threads/nodes. Verified throughput is bytes/s of pages whose first/last 8 bytes matched after successful reads; it is not a full-payload checksum. Transfer payload is 2,006,016 bytes/page.

| Case | Put p50/p95/p99 ms | Get p50/p95/p99 ms | Verified bytes/s | Errors | Verification failures |
| --- | --- | --- | ---: | --- | ---: |
| vr-r42-cn02-1100GiB | 128.885/203.667/215.916 | 368.197/371.389/371.972 | 77708269862 | {} | 0 |
| vr-r42-cn02-512GiB | 142.937/226.793/230.248 | 368.017/369.804/370.736 | 77936854589 | {} | 0 |
| vr-r42-cn05-1100GiB | 122.285/155.346/161.199 | 366.846/369.896/370.860 | 78831107855 | {} | 0 |
| vr-r42-cn05-512GiB | 118.364/187.908/191.658 | 366.899/369.006/371.166 | 78213433289 | {} | 0 |

Case `vr-r42-cn02-1100GiB`: 9714 read batches, 28 seed batches; 14/14 expected/recorded clients completed successfully; measured interval 128.391 s.
Memory evidence: minimum sampled MemAvailable=293764800 KiB; maximum sampled process VmRSS=1153667456 KiB. Nonzero IB error-counter deltas (counts, final minus first per source): {}.
Cgroup memory.events deltas (counts, final minus first): {'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn16.jsonl:oom': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn16.jsonl:oom_kill': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn16.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn16.jsonl:max': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn11.jsonl:oom': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn11.jsonl:oom_kill': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn11.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn11.jsonl:max': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn15.jsonl:oom': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn15.jsonl:oom_kill': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn15.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn15.jsonl:max': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn06.jsonl:oom': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn06.jsonl:oom_kill': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn06.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn06.jsonl:max': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn07.jsonl:oom': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn07.jsonl:oom_kill': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn07.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn07.jsonl:max': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn08.jsonl:oom': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn08.jsonl:oom_kill': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn08.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn08.jsonl:max': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn10.jsonl:oom': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn10.jsonl:oom_kill': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn10.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn10.jsonl:max': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn12.jsonl:oom': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn12.jsonl:oom_kill': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn12.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn12.jsonl:max': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn17.jsonl:oom': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn17.jsonl:oom_kill': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn17.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn17.jsonl:max': 0, 'logs/vr-r42-cn02-1100GiB/donor-health.jsonl:oom': 0, 'logs/vr-r42-cn02-1100GiB/donor-health.jsonl:oom_kill': 0, 'logs/vr-r42-cn02-1100GiB/donor-health.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn02-1100GiB/donor-health.jsonl:max': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn18.jsonl:oom': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn18.jsonl:oom_kill': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn18.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn18.jsonl:max': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn09.jsonl:oom': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn09.jsonl:oom_kill': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn09.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn09.jsonl:max': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn13.jsonl:oom': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn13.jsonl:oom_kill': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn13.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn13.jsonl:max': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn01.jsonl:oom': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn01.jsonl:oom_kill': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn01.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn01.jsonl:max': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn03.jsonl:oom': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn03.jsonl:oom_kill': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn03.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn02-1100GiB/client-vr-r42-cn03.jsonl:max': 0}; an absent entry means the counter was unavailable.
Replica coverage: 14336 descriptor records; endpoints ['172.29.30.202:16790']; address range 280289565736960 to 280319630416896 (exclusive end).
Native error text counts from `vr-r42-cn02-1100GiB/*.err`: {}.

Case `vr-r42-cn02-512GiB`: 9740 read batches, 28 seed batches; 14/14 expected/recorded clients completed successfully; measured interval 128.357 s.
Memory evidence: minimum sampled MemAvailable=912113920 KiB; maximum sampled process VmRSS=537104768 KiB. Nonzero IB error-counter deltas (counts, final minus first per source): {}.
Cgroup memory.events deltas (counts, final minus first): {'logs/vr-r42-cn02-512GiB/donor-health.jsonl:oom': 0, 'logs/vr-r42-cn02-512GiB/donor-health.jsonl:oom_kill': 0, 'logs/vr-r42-cn02-512GiB/donor-health.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn02-512GiB/donor-health.jsonl:max': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn10.jsonl:oom': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn10.jsonl:oom_kill': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn10.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn10.jsonl:max': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn08.jsonl:oom': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn08.jsonl:oom_kill': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn08.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn08.jsonl:max': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn16.jsonl:oom': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn16.jsonl:oom_kill': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn16.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn16.jsonl:max': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn11.jsonl:oom': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn11.jsonl:oom_kill': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn11.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn11.jsonl:max': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn12.jsonl:oom': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn12.jsonl:oom_kill': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn12.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn12.jsonl:max': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn17.jsonl:oom': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn17.jsonl:oom_kill': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn17.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn17.jsonl:max': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn01.jsonl:oom': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn01.jsonl:oom_kill': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn01.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn01.jsonl:max': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn07.jsonl:oom': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn07.jsonl:oom_kill': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn07.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn07.jsonl:max': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn06.jsonl:oom': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn06.jsonl:oom_kill': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn06.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn06.jsonl:max': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn13.jsonl:oom': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn13.jsonl:oom_kill': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn13.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn13.jsonl:max': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn15.jsonl:oom': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn15.jsonl:oom_kill': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn15.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn15.jsonl:max': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn03.jsonl:oom': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn03.jsonl:oom_kill': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn03.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn03.jsonl:max': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn18.jsonl:oom': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn18.jsonl:oom_kill': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn18.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn18.jsonl:max': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn09.jsonl:oom': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn09.jsonl:oom_kill': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn09.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn02-512GiB/client-vr-r42-cn09.jsonl:max': 0}; an absent entry means the counter was unavailable.
Replica coverage: 14336 descriptor records; endpoints ['172.29.30.202:16612']; address range 280920925929472 to 280950990609408 (exclusive end).
Native error text counts from `vr-r42-cn02-512GiB/*.err`: {}.

Case `vr-r42-cn05-1100GiB`: 9832 read batches, 28 seed batches; 14/14 expected/recorded clients completed successfully; measured interval 128.100 s.
Memory evidence: minimum sampled MemAvailable=302070464 KiB; maximum sampled process VmRSS=1153667456 KiB. Nonzero IB error-counter deltas (counts, final minus first per source): {}.
Cgroup memory.events deltas (counts, final minus first): {'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn08.jsonl:oom': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn08.jsonl:oom_kill': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn08.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn08.jsonl:max': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn15.jsonl:oom': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn15.jsonl:oom_kill': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn15.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn15.jsonl:max': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn11.jsonl:oom': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn11.jsonl:oom_kill': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn11.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn11.jsonl:max': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn10.jsonl:oom': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn10.jsonl:oom_kill': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn10.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn10.jsonl:max': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn06.jsonl:oom': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn06.jsonl:oom_kill': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn06.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn06.jsonl:max': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn16.jsonl:oom': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn16.jsonl:oom_kill': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn16.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn16.jsonl:max': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn13.jsonl:oom': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn13.jsonl:oom_kill': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn13.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn13.jsonl:max': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn18.jsonl:oom': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn18.jsonl:oom_kill': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn18.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn18.jsonl:max': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn01.jsonl:oom': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn01.jsonl:oom_kill': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn01.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn01.jsonl:max': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn07.jsonl:oom': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn07.jsonl:oom_kill': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn07.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn07.jsonl:max': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn09.jsonl:oom': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn09.jsonl:oom_kill': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn09.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn09.jsonl:max': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn03.jsonl:oom': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn03.jsonl:oom_kill': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn03.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn03.jsonl:max': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn17.jsonl:oom': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn17.jsonl:oom_kill': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn17.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn17.jsonl:max': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn12.jsonl:oom': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn12.jsonl:oom_kill': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn12.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn05-1100GiB/client-vr-r42-cn12.jsonl:max': 0, 'logs/vr-r42-cn05-1100GiB/donor-health.jsonl:oom': 0, 'logs/vr-r42-cn05-1100GiB/donor-health.jsonl:oom_kill': 0, 'logs/vr-r42-cn05-1100GiB/donor-health.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn05-1100GiB/donor-health.jsonl:max': 0}; an absent entry means the counter was unavailable.
Replica coverage: 14336 descriptor records; endpoints ['172.29.110.5:16144']; address range 280289565736960 to 280319630416896 (exclusive end).
Native error text counts from `vr-r42-cn05-1100GiB/*.err`: {}.

Case `vr-r42-cn05-512GiB`: 9747 read batches, 28 seed batches; 14/14 expected/recorded clients completed successfully; measured interval 127.995 s.
Memory evidence: minimum sampled MemAvailable=920255808 KiB; maximum sampled process VmRSS=537104768 KiB. Nonzero IB error-counter deltas (counts, final minus first per source): {}.
Cgroup memory.events deltas (counts, final minus first): {'logs/vr-r42-cn05-512GiB/client-vr-r42-cn03.jsonl:oom': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn03.jsonl:oom_kill': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn03.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn03.jsonl:max': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn06.jsonl:oom': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn06.jsonl:oom_kill': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn06.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn06.jsonl:max': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn15.jsonl:oom': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn15.jsonl:oom_kill': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn15.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn15.jsonl:max': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn17.jsonl:oom': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn17.jsonl:oom_kill': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn17.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn17.jsonl:max': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn10.jsonl:oom': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn10.jsonl:oom_kill': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn10.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn10.jsonl:max': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn12.jsonl:oom': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn12.jsonl:oom_kill': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn12.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn12.jsonl:max': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn11.jsonl:oom': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn11.jsonl:oom_kill': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn11.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn11.jsonl:max': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn16.jsonl:oom': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn16.jsonl:oom_kill': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn16.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn16.jsonl:max': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn18.jsonl:oom': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn18.jsonl:oom_kill': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn18.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn18.jsonl:max': 0, 'logs/vr-r42-cn05-512GiB/donor-health.jsonl:oom': 0, 'logs/vr-r42-cn05-512GiB/donor-health.jsonl:oom_kill': 0, 'logs/vr-r42-cn05-512GiB/donor-health.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn05-512GiB/donor-health.jsonl:max': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn01.jsonl:oom': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn01.jsonl:oom_kill': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn01.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn01.jsonl:max': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn08.jsonl:oom': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn08.jsonl:oom_kill': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn08.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn08.jsonl:max': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn13.jsonl:oom': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn13.jsonl:oom_kill': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn13.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn13.jsonl:max': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn09.jsonl:oom': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn09.jsonl:oom_kill': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn09.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn09.jsonl:max': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn07.jsonl:oom': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn07.jsonl:oom_kill': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn07.jsonl:oom_group_kill': 0, 'logs/vr-r42-cn05-512GiB/client-vr-r42-cn07.jsonl:max': 0}; an absent entry means the counter was unavailable.
Replica coverage: 14336 descriptor records; endpoints ['172.29.110.5:15986']; address range 280920925929472 to 280950990609408 (exclusive end).
Native error text counts from `vr-r42-cn05-512GiB/*.err`: {}.

## Node inventory

Native Slurm execution-context snapshots and test-container snapshots are listed separately. The native Slurm context may itself run in a Kubernetes pod; its OS release need not be the bare-metal root OS. Historical nonzero counters are not attributed to this run. Unavailable probes do not establish a clean node. Negative counter deltas indicate a counter reset/decrease and are not evidence of improvement.

Node `vr-r42-cn01`: OS=Ubuntu 26.04 LTS; kernel=7.0.0-2015-nvidia-bos-64k; CPU=['Olympus']; MemTotal=1490220544 KiB.
Execution context: Kubernetes Slurm worker context; readable raw IB counters=0. An empty IB counter set does not establish zero NIC errors.
IB port states: {'mlx5_0/1': '4: ACTIVE', 'mlx5_1/1': '4: ACTIVE', 'mlx5_10/1': '4: ACTIVE', 'mlx5_11/1': '4: ACTIVE', 'mlx5_2/1': '4: ACTIVE', 'mlx5_3/1': '1: DOWN', 'mlx5_4/1': '1: DOWN', 'mlx5_5/1': '4: ACTIVE', 'mlx5_6/1': '4: ACTIVE', 'mlx5_7/1': '4: ACTIVE', 'mlx5_8/1': '4: ACTIVE', 'mlx5_9/1': '4: ACTIVE'}. Command errors/missing/timeouts=10/13; sysfs/proc collection errors=20.
Network interface states: {'bonding_masters': None, 'eth0': 'up', 'lo': 'unknown', 'tunl0': 'down'}.
Preflight baseline=present; snapshots=5; nonzero link/error counter changes={'net/eth0/rx_dropped': 39}; comparable counters=45; historical nonzero counters=1. New OOM kernel messages=N/A (only retained kernel log windows are compared).
Sources: `logs/host-inventory-vr-r42-cn01.json`, `logs/vr-r42-cn05-512GiB/host-inventory-vr-r42-cn01.json`, `logs/vr-r42-cn05-1100GiB/host-inventory-vr-r42-cn01.json`, `logs/vr-r42-cn02-512GiB/host-inventory-vr-r42-cn01.json`, `logs/vr-r42-cn02-1100GiB/host-inventory-vr-r42-cn01.json`.

Post snapshot `logs/vr-r42-cn05-512GiB/host-inventory-vr-r42-cn01.json` counter changes from preflight: {'net/eth0/rx_dropped': 9}.
Post snapshot `logs/vr-r42-cn05-1100GiB/host-inventory-vr-r42-cn01.json` counter changes from preflight: {'net/eth0/rx_dropped': 19}.
Post snapshot `logs/vr-r42-cn02-512GiB/host-inventory-vr-r42-cn01.json` counter changes from preflight: {'net/eth0/rx_dropped': 29}.
Post snapshot `logs/vr-r42-cn02-1100GiB/host-inventory-vr-r42-cn01.json` counter changes from preflight: {'net/eth0/rx_dropped': 39}.
Node `vr-r42-cn02`: OS=Ubuntu 26.04 LTS; kernel=7.0.0-2015-nvidia-bos-64k; CPU=['Olympus']; MemTotal=1490220544 KiB.
Execution context: Kubernetes Slurm worker context; readable raw IB counters=0. An empty IB counter set does not establish zero NIC errors.
IB port states: {'mlx5_0/1': '4: ACTIVE', 'mlx5_1/1': '4: ACTIVE', 'mlx5_10/1': '4: ACTIVE', 'mlx5_11/1': '4: ACTIVE', 'mlx5_2/1': '4: ACTIVE', 'mlx5_3/1': '1: DOWN', 'mlx5_4/1': '1: DOWN', 'mlx5_5/1': '4: ACTIVE', 'mlx5_6/1': '4: ACTIVE', 'mlx5_7/1': '4: ACTIVE', 'mlx5_8/1': '4: ACTIVE', 'mlx5_9/1': '4: ACTIVE'}. Command errors/missing/timeouts=10/13; sysfs/proc collection errors=20.
Network interface states: {'bonding_masters': None, 'eth0': 'up', 'lo': 'unknown', 'tunl0': 'down'}.
Preflight baseline=present; snapshots=5; nonzero link/error counter changes={'net/eth0/rx_dropped': 39}; comparable counters=45; historical nonzero counters=1. New OOM kernel messages=N/A (only retained kernel log windows are compared).
Sources: `logs/host-inventory-vr-r42-cn02.json`, `logs/vr-r42-cn05-512GiB/host-inventory-vr-r42-cn02.json`, `logs/vr-r42-cn05-1100GiB/host-inventory-vr-r42-cn02.json`, `logs/vr-r42-cn02-512GiB/host-inventory-vr-r42-cn02.json`, `logs/vr-r42-cn02-1100GiB/host-inventory-vr-r42-cn02.json`.

Post snapshot `logs/vr-r42-cn05-512GiB/host-inventory-vr-r42-cn02.json` counter changes from preflight: {'net/eth0/rx_dropped': 9}.
Post snapshot `logs/vr-r42-cn05-1100GiB/host-inventory-vr-r42-cn02.json` counter changes from preflight: {'net/eth0/rx_dropped': 19}.
Post snapshot `logs/vr-r42-cn02-512GiB/host-inventory-vr-r42-cn02.json` counter changes from preflight: {'net/eth0/rx_dropped': 29}.
Post snapshot `logs/vr-r42-cn02-1100GiB/host-inventory-vr-r42-cn02.json` counter changes from preflight: {'net/eth0/rx_dropped': 39}.
Node `vr-r42-cn03`: OS=Ubuntu 26.04 LTS; kernel=7.0.0-2015-nvidia-bos-64k; CPU=['Olympus']; MemTotal=1490220544 KiB.
Execution context: Kubernetes Slurm worker context; readable raw IB counters=0. An empty IB counter set does not establish zero NIC errors.
IB port states: {'mlx5_0/1': '4: ACTIVE', 'mlx5_1/1': '4: ACTIVE', 'mlx5_10/1': '4: ACTIVE', 'mlx5_11/1': '4: ACTIVE', 'mlx5_2/1': '4: ACTIVE', 'mlx5_3/1': '1: DOWN', 'mlx5_4/1': '1: DOWN', 'mlx5_5/1': '4: ACTIVE', 'mlx5_6/1': '4: ACTIVE', 'mlx5_7/1': '4: ACTIVE', 'mlx5_8/1': '4: ACTIVE', 'mlx5_9/1': '4: ACTIVE'}. Command errors/missing/timeouts=10/13; sysfs/proc collection errors=20.
Network interface states: {'bonding_masters': None, 'eth0': 'up', 'lo': 'unknown', 'tunl0': 'down'}.
Preflight baseline=present; snapshots=5; nonzero link/error counter changes={'net/eth0/rx_dropped': 39}; comparable counters=45; historical nonzero counters=1. New OOM kernel messages=N/A (only retained kernel log windows are compared).
Sources: `logs/host-inventory-vr-r42-cn03.json`, `logs/vr-r42-cn05-512GiB/host-inventory-vr-r42-cn03.json`, `logs/vr-r42-cn05-1100GiB/host-inventory-vr-r42-cn03.json`, `logs/vr-r42-cn02-512GiB/host-inventory-vr-r42-cn03.json`, `logs/vr-r42-cn02-1100GiB/host-inventory-vr-r42-cn03.json`.

Post snapshot `logs/vr-r42-cn05-512GiB/host-inventory-vr-r42-cn03.json` counter changes from preflight: {'net/eth0/rx_dropped': 9}.
Post snapshot `logs/vr-r42-cn05-1100GiB/host-inventory-vr-r42-cn03.json` counter changes from preflight: {'net/eth0/rx_dropped': 19}.
Post snapshot `logs/vr-r42-cn02-512GiB/host-inventory-vr-r42-cn03.json` counter changes from preflight: {'net/eth0/rx_dropped': 29}.
Post snapshot `logs/vr-r42-cn02-1100GiB/host-inventory-vr-r42-cn03.json` counter changes from preflight: {'net/eth0/rx_dropped': 39}.
Node `vr-r42-cn05`: OS=Ubuntu 26.04 LTS; kernel=7.0.0-2015-nvidia-bos-64k; CPU=['Olympus']; MemTotal=1490220416 KiB.
Execution context: Kubernetes Slurm worker context; readable raw IB counters=0. An empty IB counter set does not establish zero NIC errors.
IB port states: {'mlx5_0/1': '4: ACTIVE', 'mlx5_1/1': '4: ACTIVE', 'mlx5_10/1': '4: ACTIVE', 'mlx5_11/1': '4: ACTIVE', 'mlx5_2/1': '4: ACTIVE', 'mlx5_3/1': '1: DOWN', 'mlx5_4/1': '1: DOWN', 'mlx5_5/1': '4: ACTIVE', 'mlx5_6/1': '4: ACTIVE', 'mlx5_7/1': '4: ACTIVE', 'mlx5_8/1': '4: ACTIVE', 'mlx5_9/1': '4: ACTIVE'}. Command errors/missing/timeouts=10/13; sysfs/proc collection errors=20.
Network interface states: {'bonding_masters': None, 'eth0': 'up', 'lo': 'unknown', 'tunl0': 'down'}.
Preflight baseline=present; snapshots=5; nonzero link/error counter changes={'net/eth0/rx_dropped': 39}; comparable counters=45; historical nonzero counters=1. New OOM kernel messages=N/A (only retained kernel log windows are compared).
Sources: `logs/host-inventory-vr-r42-cn05.json`, `logs/vr-r42-cn05-512GiB/host-inventory-vr-r42-cn05.json`, `logs/vr-r42-cn05-1100GiB/host-inventory-vr-r42-cn05.json`, `logs/vr-r42-cn02-512GiB/host-inventory-vr-r42-cn05.json`, `logs/vr-r42-cn02-1100GiB/host-inventory-vr-r42-cn05.json`.

Post snapshot `logs/vr-r42-cn05-512GiB/host-inventory-vr-r42-cn05.json` counter changes from preflight: {'net/eth0/rx_dropped': 9}.
Post snapshot `logs/vr-r42-cn05-1100GiB/host-inventory-vr-r42-cn05.json` counter changes from preflight: {'net/eth0/rx_dropped': 19}.
Post snapshot `logs/vr-r42-cn02-512GiB/host-inventory-vr-r42-cn05.json` counter changes from preflight: {'net/eth0/rx_dropped': 29}.
Post snapshot `logs/vr-r42-cn02-1100GiB/host-inventory-vr-r42-cn05.json` counter changes from preflight: {'net/eth0/rx_dropped': 39}.
Node `vr-r42-cn06`: OS=Ubuntu 26.04 LTS; kernel=7.0.0-2015-nvidia-bos-64k; CPU=['Olympus']; MemTotal=1490220544 KiB.
Execution context: Kubernetes Slurm worker context; readable raw IB counters=0. An empty IB counter set does not establish zero NIC errors.
IB port states: {'mlx5_0/1': '4: ACTIVE', 'mlx5_1/1': '4: ACTIVE', 'mlx5_10/1': '4: ACTIVE', 'mlx5_11/1': '4: ACTIVE', 'mlx5_2/1': '4: ACTIVE', 'mlx5_3/1': '1: DOWN', 'mlx5_4/1': '1: DOWN', 'mlx5_5/1': '4: ACTIVE', 'mlx5_6/1': '4: ACTIVE', 'mlx5_7/1': '4: ACTIVE', 'mlx5_8/1': '4: ACTIVE', 'mlx5_9/1': '4: ACTIVE'}. Command errors/missing/timeouts=10/13; sysfs/proc collection errors=20.
Network interface states: {'bonding_masters': None, 'eth0': 'up', 'lo': 'unknown', 'tunl0': 'down'}.
Preflight baseline=present; snapshots=5; nonzero link/error counter changes={'net/eth0/rx_dropped': 39}; comparable counters=45; historical nonzero counters=1. New OOM kernel messages=N/A (only retained kernel log windows are compared).
Sources: `logs/host-inventory-vr-r42-cn06.json`, `logs/vr-r42-cn05-512GiB/host-inventory-vr-r42-cn06.json`, `logs/vr-r42-cn05-1100GiB/host-inventory-vr-r42-cn06.json`, `logs/vr-r42-cn02-512GiB/host-inventory-vr-r42-cn06.json`, `logs/vr-r42-cn02-1100GiB/host-inventory-vr-r42-cn06.json`.

Post snapshot `logs/vr-r42-cn05-512GiB/host-inventory-vr-r42-cn06.json` counter changes from preflight: {'net/eth0/rx_dropped': 9}.
Post snapshot `logs/vr-r42-cn05-1100GiB/host-inventory-vr-r42-cn06.json` counter changes from preflight: {'net/eth0/rx_dropped': 19}.
Post snapshot `logs/vr-r42-cn02-512GiB/host-inventory-vr-r42-cn06.json` counter changes from preflight: {'net/eth0/rx_dropped': 29}.
Post snapshot `logs/vr-r42-cn02-1100GiB/host-inventory-vr-r42-cn06.json` counter changes from preflight: {'net/eth0/rx_dropped': 39}.
Node `vr-r42-cn07`: OS=Ubuntu 26.04 LTS; kernel=7.0.0-2015-nvidia-bos-64k; CPU=['Olympus']; MemTotal=1490220544 KiB.
Execution context: Kubernetes Slurm worker context; readable raw IB counters=0. An empty IB counter set does not establish zero NIC errors.
IB port states: {'mlx5_0/1': '4: ACTIVE', 'mlx5_1/1': '4: ACTIVE', 'mlx5_10/1': '4: ACTIVE', 'mlx5_11/1': '4: ACTIVE', 'mlx5_2/1': '4: ACTIVE', 'mlx5_3/1': '1: DOWN', 'mlx5_4/1': '1: DOWN', 'mlx5_5/1': '4: ACTIVE', 'mlx5_6/1': '4: ACTIVE', 'mlx5_7/1': '4: ACTIVE', 'mlx5_8/1': '4: ACTIVE', 'mlx5_9/1': '4: ACTIVE'}. Command errors/missing/timeouts=10/13; sysfs/proc collection errors=20.
Network interface states: {'bonding_masters': None, 'eth0': 'up', 'lo': 'unknown', 'tunl0': 'down'}.
Preflight baseline=present; snapshots=5; nonzero link/error counter changes={'net/eth0/rx_dropped': 39}; comparable counters=45; historical nonzero counters=1. New OOM kernel messages=N/A (only retained kernel log windows are compared).
Sources: `logs/host-inventory-vr-r42-cn07.json`, `logs/vr-r42-cn05-512GiB/host-inventory-vr-r42-cn07.json`, `logs/vr-r42-cn05-1100GiB/host-inventory-vr-r42-cn07.json`, `logs/vr-r42-cn02-512GiB/host-inventory-vr-r42-cn07.json`, `logs/vr-r42-cn02-1100GiB/host-inventory-vr-r42-cn07.json`.

Post snapshot `logs/vr-r42-cn05-512GiB/host-inventory-vr-r42-cn07.json` counter changes from preflight: {'net/eth0/rx_dropped': 9}.
Post snapshot `logs/vr-r42-cn05-1100GiB/host-inventory-vr-r42-cn07.json` counter changes from preflight: {'net/eth0/rx_dropped': 19}.
Post snapshot `logs/vr-r42-cn02-512GiB/host-inventory-vr-r42-cn07.json` counter changes from preflight: {'net/eth0/rx_dropped': 29}.
Post snapshot `logs/vr-r42-cn02-1100GiB/host-inventory-vr-r42-cn07.json` counter changes from preflight: {'net/eth0/rx_dropped': 39}.
Node `vr-r42-cn08`: OS=Ubuntu 26.04 LTS; kernel=7.0.0-2015-nvidia-bos-64k; CPU=['Olympus']; MemTotal=1490220608 KiB.
Execution context: Kubernetes Slurm worker context; readable raw IB counters=0. An empty IB counter set does not establish zero NIC errors.
IB port states: {'mlx5_0/1': '4: ACTIVE', 'mlx5_1/1': '4: ACTIVE', 'mlx5_10/1': '4: ACTIVE', 'mlx5_11/1': '4: ACTIVE', 'mlx5_2/1': '4: ACTIVE', 'mlx5_3/1': '1: DOWN', 'mlx5_4/1': '1: DOWN', 'mlx5_5/1': '4: ACTIVE', 'mlx5_6/1': '4: ACTIVE', 'mlx5_7/1': '4: ACTIVE', 'mlx5_8/1': '4: ACTIVE', 'mlx5_9/1': '4: ACTIVE'}. Command errors/missing/timeouts=10/13; sysfs/proc collection errors=20.
Network interface states: {'bonding_masters': None, 'eth0': 'up', 'lo': 'unknown', 'tunl0': 'down'}.
Preflight baseline=present; snapshots=5; nonzero link/error counter changes={'net/eth0/rx_dropped': 39}; comparable counters=45; historical nonzero counters=1. New OOM kernel messages=N/A (only retained kernel log windows are compared).
Sources: `logs/host-inventory-vr-r42-cn08.json`, `logs/vr-r42-cn05-512GiB/host-inventory-vr-r42-cn08.json`, `logs/vr-r42-cn05-1100GiB/host-inventory-vr-r42-cn08.json`, `logs/vr-r42-cn02-512GiB/host-inventory-vr-r42-cn08.json`, `logs/vr-r42-cn02-1100GiB/host-inventory-vr-r42-cn08.json`.

Post snapshot `logs/vr-r42-cn05-512GiB/host-inventory-vr-r42-cn08.json` counter changes from preflight: {'net/eth0/rx_dropped': 9}.
Post snapshot `logs/vr-r42-cn05-1100GiB/host-inventory-vr-r42-cn08.json` counter changes from preflight: {'net/eth0/rx_dropped': 19}.
Post snapshot `logs/vr-r42-cn02-512GiB/host-inventory-vr-r42-cn08.json` counter changes from preflight: {'net/eth0/rx_dropped': 29}.
Post snapshot `logs/vr-r42-cn02-1100GiB/host-inventory-vr-r42-cn08.json` counter changes from preflight: {'net/eth0/rx_dropped': 39}.
Node `vr-r42-cn09`: OS=Ubuntu 26.04 LTS; kernel=7.0.0-2015-nvidia-bos-64k; CPU=['Olympus']; MemTotal=1490220480 KiB.
Execution context: Kubernetes Slurm worker context; readable raw IB counters=0. An empty IB counter set does not establish zero NIC errors.
IB port states: {'mlx5_0/1': '4: ACTIVE', 'mlx5_1/1': '4: ACTIVE', 'mlx5_10/1': '4: ACTIVE', 'mlx5_11/1': '4: ACTIVE', 'mlx5_2/1': '4: ACTIVE', 'mlx5_3/1': '1: DOWN', 'mlx5_4/1': '1: DOWN', 'mlx5_5/1': '4: ACTIVE', 'mlx5_6/1': '4: ACTIVE', 'mlx5_7/1': '4: ACTIVE', 'mlx5_8/1': '4: ACTIVE', 'mlx5_9/1': '4: ACTIVE'}. Command errors/missing/timeouts=10/13; sysfs/proc collection errors=20.
Network interface states: {'bonding_masters': None, 'eth0': 'up', 'lo': 'unknown', 'tunl0': 'down'}.
Preflight baseline=present; snapshots=5; nonzero link/error counter changes={'net/eth0/rx_dropped': 39}; comparable counters=45; historical nonzero counters=1. New OOM kernel messages=N/A (only retained kernel log windows are compared).
Sources: `logs/host-inventory-vr-r42-cn09.json`, `logs/vr-r42-cn05-512GiB/host-inventory-vr-r42-cn09.json`, `logs/vr-r42-cn05-1100GiB/host-inventory-vr-r42-cn09.json`, `logs/vr-r42-cn02-512GiB/host-inventory-vr-r42-cn09.json`, `logs/vr-r42-cn02-1100GiB/host-inventory-vr-r42-cn09.json`.

Post snapshot `logs/vr-r42-cn05-512GiB/host-inventory-vr-r42-cn09.json` counter changes from preflight: {'net/eth0/rx_dropped': 9}.
Post snapshot `logs/vr-r42-cn05-1100GiB/host-inventory-vr-r42-cn09.json` counter changes from preflight: {'net/eth0/rx_dropped': 19}.
Post snapshot `logs/vr-r42-cn02-512GiB/host-inventory-vr-r42-cn09.json` counter changes from preflight: {'net/eth0/rx_dropped': 29}.
Post snapshot `logs/vr-r42-cn02-1100GiB/host-inventory-vr-r42-cn09.json` counter changes from preflight: {'net/eth0/rx_dropped': 39}.
Node `vr-r42-cn10`: OS=Ubuntu 26.04 LTS; kernel=7.0.0-2015-nvidia-bos-64k; CPU=['Olympus']; MemTotal=1490220608 KiB.
Execution context: Kubernetes Slurm worker context; readable raw IB counters=0. An empty IB counter set does not establish zero NIC errors.
IB port states: {'mlx5_0/1': '4: ACTIVE', 'mlx5_1/1': '4: ACTIVE', 'mlx5_10/1': '4: ACTIVE', 'mlx5_11/1': '4: ACTIVE', 'mlx5_2/1': '4: ACTIVE', 'mlx5_3/1': '1: DOWN', 'mlx5_4/1': '1: DOWN', 'mlx5_5/1': '4: ACTIVE', 'mlx5_6/1': '4: ACTIVE', 'mlx5_7/1': '4: ACTIVE', 'mlx5_8/1': '4: ACTIVE', 'mlx5_9/1': '4: ACTIVE'}. Command errors/missing/timeouts=10/13; sysfs/proc collection errors=20.
Network interface states: {'bonding_masters': None, 'eth0': 'up', 'lo': 'unknown', 'tunl0': 'down'}.
Preflight baseline=present; snapshots=5; nonzero link/error counter changes={'net/eth0/rx_dropped': 39}; comparable counters=45; historical nonzero counters=1. New OOM kernel messages=N/A (only retained kernel log windows are compared).
Sources: `logs/host-inventory-vr-r42-cn10.json`, `logs/vr-r42-cn05-512GiB/host-inventory-vr-r42-cn10.json`, `logs/vr-r42-cn05-1100GiB/host-inventory-vr-r42-cn10.json`, `logs/vr-r42-cn02-512GiB/host-inventory-vr-r42-cn10.json`, `logs/vr-r42-cn02-1100GiB/host-inventory-vr-r42-cn10.json`.

Post snapshot `logs/vr-r42-cn05-512GiB/host-inventory-vr-r42-cn10.json` counter changes from preflight: {'net/eth0/rx_dropped': 9}.
Post snapshot `logs/vr-r42-cn05-1100GiB/host-inventory-vr-r42-cn10.json` counter changes from preflight: {'net/eth0/rx_dropped': 19}.
Post snapshot `logs/vr-r42-cn02-512GiB/host-inventory-vr-r42-cn10.json` counter changes from preflight: {'net/eth0/rx_dropped': 29}.
Post snapshot `logs/vr-r42-cn02-1100GiB/host-inventory-vr-r42-cn10.json` counter changes from preflight: {'net/eth0/rx_dropped': 39}.
Node `vr-r42-cn11`: OS=Ubuntu 26.04 LTS; kernel=7.0.0-2015-nvidia-bos-64k; CPU=['Olympus']; MemTotal=1490220608 KiB.
Execution context: Kubernetes Slurm worker context; readable raw IB counters=0. An empty IB counter set does not establish zero NIC errors.
IB port states: {'mlx5_0/1': '4: ACTIVE', 'mlx5_1/1': '4: ACTIVE', 'mlx5_10/1': '4: ACTIVE', 'mlx5_11/1': '4: ACTIVE', 'mlx5_2/1': '4: ACTIVE', 'mlx5_3/1': '1: DOWN', 'mlx5_4/1': '1: DOWN', 'mlx5_5/1': '4: ACTIVE', 'mlx5_6/1': '4: ACTIVE', 'mlx5_7/1': '4: ACTIVE', 'mlx5_8/1': '4: ACTIVE', 'mlx5_9/1': '4: ACTIVE'}. Command errors/missing/timeouts=10/13; sysfs/proc collection errors=20.
Network interface states: {'bonding_masters': None, 'eth0': 'up', 'lo': 'unknown', 'tunl0': 'down'}.
Preflight baseline=present; snapshots=5; nonzero link/error counter changes={'net/eth0/rx_dropped': 39}; comparable counters=45; historical nonzero counters=1. New OOM kernel messages=N/A (only retained kernel log windows are compared).
Sources: `logs/host-inventory-vr-r42-cn11.json`, `logs/vr-r42-cn05-512GiB/host-inventory-vr-r42-cn11.json`, `logs/vr-r42-cn05-1100GiB/host-inventory-vr-r42-cn11.json`, `logs/vr-r42-cn02-512GiB/host-inventory-vr-r42-cn11.json`, `logs/vr-r42-cn02-1100GiB/host-inventory-vr-r42-cn11.json`.

Post snapshot `logs/vr-r42-cn05-512GiB/host-inventory-vr-r42-cn11.json` counter changes from preflight: {'net/eth0/rx_dropped': 9}.
Post snapshot `logs/vr-r42-cn05-1100GiB/host-inventory-vr-r42-cn11.json` counter changes from preflight: {'net/eth0/rx_dropped': 19}.
Post snapshot `logs/vr-r42-cn02-512GiB/host-inventory-vr-r42-cn11.json` counter changes from preflight: {'net/eth0/rx_dropped': 29}.
Post snapshot `logs/vr-r42-cn02-1100GiB/host-inventory-vr-r42-cn11.json` counter changes from preflight: {'net/eth0/rx_dropped': 39}.
Node `vr-r42-cn12`: OS=Ubuntu 26.04 LTS; kernel=7.0.0-2015-nvidia-bos-64k; CPU=['Olympus']; MemTotal=1490220544 KiB.
Execution context: Kubernetes Slurm worker context; readable raw IB counters=0. An empty IB counter set does not establish zero NIC errors.
IB port states: {'mlx5_0/1': '4: ACTIVE', 'mlx5_1/1': '4: ACTIVE', 'mlx5_10/1': '4: ACTIVE', 'mlx5_11/1': '4: ACTIVE', 'mlx5_2/1': '4: ACTIVE', 'mlx5_3/1': '1: DOWN', 'mlx5_4/1': '1: DOWN', 'mlx5_5/1': '4: ACTIVE', 'mlx5_6/1': '4: ACTIVE', 'mlx5_7/1': '4: ACTIVE', 'mlx5_8/1': '4: ACTIVE', 'mlx5_9/1': '4: ACTIVE'}. Command errors/missing/timeouts=10/13; sysfs/proc collection errors=20.
Network interface states: {'bonding_masters': None, 'eth0': 'up', 'lo': 'unknown', 'tunl0': 'down'}.
Preflight baseline=present; snapshots=5; nonzero link/error counter changes={'net/eth0/rx_dropped': 39}; comparable counters=45; historical nonzero counters=1. New OOM kernel messages=N/A (only retained kernel log windows are compared).
Sources: `logs/host-inventory-vr-r42-cn12.json`, `logs/vr-r42-cn05-512GiB/host-inventory-vr-r42-cn12.json`, `logs/vr-r42-cn05-1100GiB/host-inventory-vr-r42-cn12.json`, `logs/vr-r42-cn02-512GiB/host-inventory-vr-r42-cn12.json`, `logs/vr-r42-cn02-1100GiB/host-inventory-vr-r42-cn12.json`.

Post snapshot `logs/vr-r42-cn05-512GiB/host-inventory-vr-r42-cn12.json` counter changes from preflight: {'net/eth0/rx_dropped': 9}.
Post snapshot `logs/vr-r42-cn05-1100GiB/host-inventory-vr-r42-cn12.json` counter changes from preflight: {'net/eth0/rx_dropped': 19}.
Post snapshot `logs/vr-r42-cn02-512GiB/host-inventory-vr-r42-cn12.json` counter changes from preflight: {'net/eth0/rx_dropped': 29}.
Post snapshot `logs/vr-r42-cn02-1100GiB/host-inventory-vr-r42-cn12.json` counter changes from preflight: {'net/eth0/rx_dropped': 39}.
Node `vr-r42-cn13`: OS=Ubuntu 26.04 LTS; kernel=7.0.0-2015-nvidia-bos-64k; CPU=['Olympus']; MemTotal=1490220480 KiB.
Execution context: Kubernetes Slurm worker context; readable raw IB counters=0. An empty IB counter set does not establish zero NIC errors.
IB port states: {'mlx5_0/1': '4: ACTIVE', 'mlx5_1/1': '4: ACTIVE', 'mlx5_10/1': '4: ACTIVE', 'mlx5_11/1': '4: ACTIVE', 'mlx5_2/1': '4: ACTIVE', 'mlx5_3/1': '1: DOWN', 'mlx5_4/1': '1: DOWN', 'mlx5_5/1': '4: ACTIVE', 'mlx5_6/1': '4: ACTIVE', 'mlx5_7/1': '4: ACTIVE', 'mlx5_8/1': '4: ACTIVE', 'mlx5_9/1': '4: ACTIVE'}. Command errors/missing/timeouts=10/13; sysfs/proc collection errors=20.
Network interface states: {'bonding_masters': None, 'eth0': 'up', 'lo': 'unknown', 'tunl0': 'down'}.
Preflight baseline=present; snapshots=5; nonzero link/error counter changes={'net/eth0/rx_dropped': 39}; comparable counters=45; historical nonzero counters=1. New OOM kernel messages=N/A (only retained kernel log windows are compared).
Sources: `logs/host-inventory-vr-r42-cn13.json`, `logs/vr-r42-cn05-512GiB/host-inventory-vr-r42-cn13.json`, `logs/vr-r42-cn05-1100GiB/host-inventory-vr-r42-cn13.json`, `logs/vr-r42-cn02-512GiB/host-inventory-vr-r42-cn13.json`, `logs/vr-r42-cn02-1100GiB/host-inventory-vr-r42-cn13.json`.

Post snapshot `logs/vr-r42-cn05-512GiB/host-inventory-vr-r42-cn13.json` counter changes from preflight: {'net/eth0/rx_dropped': 9}.
Post snapshot `logs/vr-r42-cn05-1100GiB/host-inventory-vr-r42-cn13.json` counter changes from preflight: {'net/eth0/rx_dropped': 19}.
Post snapshot `logs/vr-r42-cn02-512GiB/host-inventory-vr-r42-cn13.json` counter changes from preflight: {'net/eth0/rx_dropped': 29}.
Post snapshot `logs/vr-r42-cn02-1100GiB/host-inventory-vr-r42-cn13.json` counter changes from preflight: {'net/eth0/rx_dropped': 39}.
Node `vr-r42-cn15`: OS=Ubuntu 26.04 LTS; kernel=7.0.0-2015-nvidia-bos-64k; CPU=['Olympus']; MemTotal=1490220608 KiB.
Execution context: Kubernetes Slurm worker context; readable raw IB counters=0. An empty IB counter set does not establish zero NIC errors.
IB port states: {'mlx5_0/1': '4: ACTIVE', 'mlx5_1/1': '4: ACTIVE', 'mlx5_10/1': '4: ACTIVE', 'mlx5_11/1': '4: ACTIVE', 'mlx5_2/1': '4: ACTIVE', 'mlx5_3/1': '1: DOWN', 'mlx5_4/1': '1: DOWN', 'mlx5_5/1': '4: ACTIVE', 'mlx5_6/1': '4: ACTIVE', 'mlx5_7/1': '4: ACTIVE', 'mlx5_8/1': '4: ACTIVE', 'mlx5_9/1': '4: ACTIVE'}. Command errors/missing/timeouts=10/13; sysfs/proc collection errors=20.
Network interface states: {'bonding_masters': None, 'eth0': 'up', 'lo': 'unknown', 'tunl0': 'down'}.
Preflight baseline=present; snapshots=5; nonzero link/error counter changes={'net/eth0/rx_dropped': 39}; comparable counters=45; historical nonzero counters=1. New OOM kernel messages=N/A (only retained kernel log windows are compared).
Sources: `logs/host-inventory-vr-r42-cn15.json`, `logs/vr-r42-cn05-512GiB/host-inventory-vr-r42-cn15.json`, `logs/vr-r42-cn05-1100GiB/host-inventory-vr-r42-cn15.json`, `logs/vr-r42-cn02-512GiB/host-inventory-vr-r42-cn15.json`, `logs/vr-r42-cn02-1100GiB/host-inventory-vr-r42-cn15.json`.

Post snapshot `logs/vr-r42-cn05-512GiB/host-inventory-vr-r42-cn15.json` counter changes from preflight: {'net/eth0/rx_dropped': 9}.
Post snapshot `logs/vr-r42-cn05-1100GiB/host-inventory-vr-r42-cn15.json` counter changes from preflight: {'net/eth0/rx_dropped': 19}.
Post snapshot `logs/vr-r42-cn02-512GiB/host-inventory-vr-r42-cn15.json` counter changes from preflight: {'net/eth0/rx_dropped': 29}.
Post snapshot `logs/vr-r42-cn02-1100GiB/host-inventory-vr-r42-cn15.json` counter changes from preflight: {'net/eth0/rx_dropped': 39}.
Node `vr-r42-cn16`: OS=Ubuntu 26.04 LTS; kernel=7.0.0-2015-nvidia-bos-64k; CPU=['Olympus']; MemTotal=1490220544 KiB.
Execution context: Kubernetes Slurm worker context; readable raw IB counters=0. An empty IB counter set does not establish zero NIC errors.
IB port states: {'mlx5_0/1': '4: ACTIVE', 'mlx5_1/1': '4: ACTIVE', 'mlx5_10/1': '4: ACTIVE', 'mlx5_11/1': '4: ACTIVE', 'mlx5_2/1': '4: ACTIVE', 'mlx5_3/1': '1: DOWN', 'mlx5_4/1': '1: DOWN', 'mlx5_5/1': '4: ACTIVE', 'mlx5_6/1': '4: ACTIVE', 'mlx5_7/1': '4: ACTIVE', 'mlx5_8/1': '4: ACTIVE', 'mlx5_9/1': '4: ACTIVE'}. Command errors/missing/timeouts=10/13; sysfs/proc collection errors=20.
Network interface states: {'bonding_masters': None, 'eth0': 'up', 'lo': 'unknown', 'tunl0': 'down'}.
Preflight baseline=present; snapshots=5; nonzero link/error counter changes={'net/eth0/rx_dropped': 39}; comparable counters=45; historical nonzero counters=1. New OOM kernel messages=N/A (only retained kernel log windows are compared).
Sources: `logs/host-inventory-vr-r42-cn16.json`, `logs/vr-r42-cn05-512GiB/host-inventory-vr-r42-cn16.json`, `logs/vr-r42-cn05-1100GiB/host-inventory-vr-r42-cn16.json`, `logs/vr-r42-cn02-512GiB/host-inventory-vr-r42-cn16.json`, `logs/vr-r42-cn02-1100GiB/host-inventory-vr-r42-cn16.json`.

Post snapshot `logs/vr-r42-cn05-512GiB/host-inventory-vr-r42-cn16.json` counter changes from preflight: {'net/eth0/rx_dropped': 9}.
Post snapshot `logs/vr-r42-cn05-1100GiB/host-inventory-vr-r42-cn16.json` counter changes from preflight: {'net/eth0/rx_dropped': 19}.
Post snapshot `logs/vr-r42-cn02-512GiB/host-inventory-vr-r42-cn16.json` counter changes from preflight: {'net/eth0/rx_dropped': 29}.
Post snapshot `logs/vr-r42-cn02-1100GiB/host-inventory-vr-r42-cn16.json` counter changes from preflight: {'net/eth0/rx_dropped': 39}.
Node `vr-r42-cn17`: OS=Ubuntu 26.04 LTS; kernel=7.0.0-2015-nvidia-bos-64k; CPU=['Olympus']; MemTotal=1490220544 KiB.
Execution context: Kubernetes Slurm worker context; readable raw IB counters=0. An empty IB counter set does not establish zero NIC errors.
IB port states: {'mlx5_0/1': '4: ACTIVE', 'mlx5_1/1': '4: ACTIVE', 'mlx5_10/1': '4: ACTIVE', 'mlx5_11/1': '4: ACTIVE', 'mlx5_2/1': '4: ACTIVE', 'mlx5_3/1': '1: DOWN', 'mlx5_4/1': '1: DOWN', 'mlx5_5/1': '4: ACTIVE', 'mlx5_6/1': '4: ACTIVE', 'mlx5_7/1': '4: ACTIVE', 'mlx5_8/1': '4: ACTIVE', 'mlx5_9/1': '4: ACTIVE'}. Command errors/missing/timeouts=10/13; sysfs/proc collection errors=20.
Network interface states: {'bonding_masters': None, 'eth0': 'up', 'lo': 'unknown', 'tunl0': 'down'}.
Preflight baseline=present; snapshots=5; nonzero link/error counter changes={'net/eth0/rx_dropped': 39}; comparable counters=45; historical nonzero counters=1. New OOM kernel messages=N/A (only retained kernel log windows are compared).
Sources: `logs/host-inventory-vr-r42-cn17.json`, `logs/vr-r42-cn05-512GiB/host-inventory-vr-r42-cn17.json`, `logs/vr-r42-cn05-1100GiB/host-inventory-vr-r42-cn17.json`, `logs/vr-r42-cn02-512GiB/host-inventory-vr-r42-cn17.json`, `logs/vr-r42-cn02-1100GiB/host-inventory-vr-r42-cn17.json`.

Post snapshot `logs/vr-r42-cn05-512GiB/host-inventory-vr-r42-cn17.json` counter changes from preflight: {'net/eth0/rx_dropped': 9}.
Post snapshot `logs/vr-r42-cn05-1100GiB/host-inventory-vr-r42-cn17.json` counter changes from preflight: {'net/eth0/rx_dropped': 19}.
Post snapshot `logs/vr-r42-cn02-512GiB/host-inventory-vr-r42-cn17.json` counter changes from preflight: {'net/eth0/rx_dropped': 29}.
Post snapshot `logs/vr-r42-cn02-1100GiB/host-inventory-vr-r42-cn17.json` counter changes from preflight: {'net/eth0/rx_dropped': 39}.
Node `vr-r42-cn18`: OS=Ubuntu 26.04 LTS; kernel=7.0.0-2015-nvidia-bos-64k; CPU=['Olympus']; MemTotal=1490220544 KiB.
Execution context: Kubernetes Slurm worker context; readable raw IB counters=0. An empty IB counter set does not establish zero NIC errors.
IB port states: {'mlx5_0/1': '4: ACTIVE', 'mlx5_1/1': '4: ACTIVE', 'mlx5_10/1': '4: ACTIVE', 'mlx5_11/1': '4: ACTIVE', 'mlx5_2/1': '4: ACTIVE', 'mlx5_3/1': '1: DOWN', 'mlx5_4/1': '1: DOWN', 'mlx5_5/1': '4: ACTIVE', 'mlx5_6/1': '4: ACTIVE', 'mlx5_7/1': '4: ACTIVE', 'mlx5_8/1': '4: ACTIVE', 'mlx5_9/1': '4: ACTIVE'}. Command errors/missing/timeouts=10/13; sysfs/proc collection errors=20.
Network interface states: {'bonding_masters': None, 'eth0': 'up', 'lo': 'unknown', 'tunl0': 'down'}.
Preflight baseline=present; snapshots=5; nonzero link/error counter changes={'net/eth0/rx_dropped': 39}; comparable counters=45; historical nonzero counters=1. New OOM kernel messages=N/A (only retained kernel log windows are compared).
Sources: `logs/host-inventory-vr-r42-cn18.json`, `logs/vr-r42-cn05-512GiB/host-inventory-vr-r42-cn18.json`, `logs/vr-r42-cn05-1100GiB/host-inventory-vr-r42-cn18.json`, `logs/vr-r42-cn02-512GiB/host-inventory-vr-r42-cn18.json`, `logs/vr-r42-cn02-1100GiB/host-inventory-vr-r42-cn18.json`.

Post snapshot `logs/vr-r42-cn05-512GiB/host-inventory-vr-r42-cn18.json` counter changes from preflight: {'net/eth0/rx_dropped': 9}.
Post snapshot `logs/vr-r42-cn05-1100GiB/host-inventory-vr-r42-cn18.json` counter changes from preflight: {'net/eth0/rx_dropped': 19}.
Post snapshot `logs/vr-r42-cn02-512GiB/host-inventory-vr-r42-cn18.json` counter changes from preflight: {'net/eth0/rx_dropped': 29}.
Post snapshot `logs/vr-r42-cn02-1100GiB/host-inventory-vr-r42-cn18.json` counter changes from preflight: {'net/eth0/rx_dropped': 39}.
Container inventory sources: `logs/inventory-vr-r42-cn01.json`, `logs/inventory-vr-r42-cn02.json`, `logs/inventory-vr-r42-cn03.json`, `logs/inventory-vr-r42-cn05.json`, `logs/inventory-vr-r42-cn06.json`, `logs/inventory-vr-r42-cn07.json`, `logs/inventory-vr-r42-cn08.json`, `logs/inventory-vr-r42-cn09.json`, `logs/inventory-vr-r42-cn10.json`, `logs/inventory-vr-r42-cn11.json`, `logs/inventory-vr-r42-cn12.json`, `logs/inventory-vr-r42-cn13.json`, `logs/inventory-vr-r42-cn15.json`, `logs/inventory-vr-r42-cn16.json`, `logs/inventory-vr-r42-cn17.json`, `logs/inventory-vr-r42-cn18.json`, `logs/vr-r42-cn02-1100GiB/inventory-vr-r42-cn01.json`, `logs/vr-r42-cn02-1100GiB/inventory-vr-r42-cn02.json`, `logs/vr-r42-cn02-1100GiB/inventory-vr-r42-cn03.json`, `logs/vr-r42-cn02-1100GiB/inventory-vr-r42-cn05.json`, `logs/vr-r42-cn02-1100GiB/inventory-vr-r42-cn06.json`, `logs/vr-r42-cn02-1100GiB/inventory-vr-r42-cn07.json`, `logs/vr-r42-cn02-1100GiB/inventory-vr-r42-cn08.json`, `logs/vr-r42-cn02-1100GiB/inventory-vr-r42-cn09.json`, `logs/vr-r42-cn02-1100GiB/inventory-vr-r42-cn10.json`, `logs/vr-r42-cn02-1100GiB/inventory-vr-r42-cn11.json`, `logs/vr-r42-cn02-1100GiB/inventory-vr-r42-cn12.json`, `logs/vr-r42-cn02-1100GiB/inventory-vr-r42-cn13.json`, `logs/vr-r42-cn02-1100GiB/inventory-vr-r42-cn15.json`, `logs/vr-r42-cn02-1100GiB/inventory-vr-r42-cn16.json`, `logs/vr-r42-cn02-1100GiB/inventory-vr-r42-cn17.json`, `logs/vr-r42-cn02-1100GiB/inventory-vr-r42-cn18.json`, `logs/vr-r42-cn02-512GiB/inventory-vr-r42-cn01.json`, `logs/vr-r42-cn02-512GiB/inventory-vr-r42-cn02.json`, `logs/vr-r42-cn02-512GiB/inventory-vr-r42-cn03.json`, `logs/vr-r42-cn02-512GiB/inventory-vr-r42-cn05.json`, `logs/vr-r42-cn02-512GiB/inventory-vr-r42-cn06.json`, `logs/vr-r42-cn02-512GiB/inventory-vr-r42-cn07.json`, `logs/vr-r42-cn02-512GiB/inventory-vr-r42-cn08.json`, `logs/vr-r42-cn02-512GiB/inventory-vr-r42-cn09.json`, `logs/vr-r42-cn02-512GiB/inventory-vr-r42-cn10.json`, `logs/vr-r42-cn02-512GiB/inventory-vr-r42-cn11.json`, `logs/vr-r42-cn02-512GiB/inventory-vr-r42-cn12.json`, `logs/vr-r42-cn02-512GiB/inventory-vr-r42-cn13.json`, `logs/vr-r42-cn02-512GiB/inventory-vr-r42-cn15.json`, `logs/vr-r42-cn02-512GiB/inventory-vr-r42-cn16.json`, `logs/vr-r42-cn02-512GiB/inventory-vr-r42-cn17.json`, `logs/vr-r42-cn02-512GiB/inventory-vr-r42-cn18.json`, `logs/vr-r42-cn05-1100GiB/inventory-vr-r42-cn01.json`, `logs/vr-r42-cn05-1100GiB/inventory-vr-r42-cn02.json`, `logs/vr-r42-cn05-1100GiB/inventory-vr-r42-cn03.json`, `logs/vr-r42-cn05-1100GiB/inventory-vr-r42-cn05.json`, `logs/vr-r42-cn05-1100GiB/inventory-vr-r42-cn06.json`, `logs/vr-r42-cn05-1100GiB/inventory-vr-r42-cn07.json`, `logs/vr-r42-cn05-1100GiB/inventory-vr-r42-cn08.json`, `logs/vr-r42-cn05-1100GiB/inventory-vr-r42-cn09.json`, `logs/vr-r42-cn05-1100GiB/inventory-vr-r42-cn10.json`, `logs/vr-r42-cn05-1100GiB/inventory-vr-r42-cn11.json`, `logs/vr-r42-cn05-1100GiB/inventory-vr-r42-cn12.json`, `logs/vr-r42-cn05-1100GiB/inventory-vr-r42-cn13.json`, `logs/vr-r42-cn05-1100GiB/inventory-vr-r42-cn15.json`, `logs/vr-r42-cn05-1100GiB/inventory-vr-r42-cn16.json`, `logs/vr-r42-cn05-1100GiB/inventory-vr-r42-cn17.json`, `logs/vr-r42-cn05-1100GiB/inventory-vr-r42-cn18.json`, `logs/vr-r42-cn05-512GiB/inventory-vr-r42-cn01.json`, `logs/vr-r42-cn05-512GiB/inventory-vr-r42-cn02.json`, `logs/vr-r42-cn05-512GiB/inventory-vr-r42-cn03.json`, `logs/vr-r42-cn05-512GiB/inventory-vr-r42-cn05.json`, `logs/vr-r42-cn05-512GiB/inventory-vr-r42-cn06.json`, `logs/vr-r42-cn05-512GiB/inventory-vr-r42-cn07.json`, `logs/vr-r42-cn05-512GiB/inventory-vr-r42-cn08.json`, `logs/vr-r42-cn05-512GiB/inventory-vr-r42-cn09.json`, `logs/vr-r42-cn05-512GiB/inventory-vr-r42-cn10.json`, `logs/vr-r42-cn05-512GiB/inventory-vr-r42-cn11.json`, `logs/vr-r42-cn05-512GiB/inventory-vr-r42-cn12.json`, `logs/vr-r42-cn05-512GiB/inventory-vr-r42-cn13.json`, `logs/vr-r42-cn05-512GiB/inventory-vr-r42-cn15.json`, `logs/vr-r42-cn05-512GiB/inventory-vr-r42-cn16.json`, `logs/vr-r42-cn05-512GiB/inventory-vr-r42-cn17.json`, `logs/vr-r42-cn05-512GiB/inventory-vr-r42-cn18.json`.

Fatal/worker/malformed records: 0. TCP endpoint probe failures: 0/3376.
External controller probe failures: 0/60.
TCP probes use only the P2P listener parsed from donor native stdout/stderr. They verify connection establishment, not RDMA success; store/replica endpoint names may use a different port.

Sources: `logs/vr-r42-cn02-1100GiB/client-vr-r42-cn01.jsonl`, `logs/vr-r42-cn02-1100GiB/client-vr-r42-cn03.jsonl`, `logs/vr-r42-cn02-1100GiB/client-vr-r42-cn06.jsonl`, `logs/vr-r42-cn02-1100GiB/client-vr-r42-cn07.jsonl`, `logs/vr-r42-cn02-1100GiB/client-vr-r42-cn08.jsonl`, `logs/vr-r42-cn02-1100GiB/client-vr-r42-cn09.jsonl`, `logs/vr-r42-cn02-1100GiB/client-vr-r42-cn10.jsonl`, `logs/vr-r42-cn02-1100GiB/client-vr-r42-cn11.jsonl`, `logs/vr-r42-cn02-1100GiB/client-vr-r42-cn12.jsonl`, `logs/vr-r42-cn02-1100GiB/client-vr-r42-cn13.jsonl`, `logs/vr-r42-cn02-1100GiB/client-vr-r42-cn15.jsonl`, `logs/vr-r42-cn02-1100GiB/client-vr-r42-cn16.jsonl`, `logs/vr-r42-cn02-1100GiB/client-vr-r42-cn17.jsonl`, `logs/vr-r42-cn02-1100GiB/client-vr-r42-cn18.jsonl`, `logs/vr-r42-cn02-1100GiB/donor-health.jsonl`, `logs/vr-r42-cn02-1100GiB/external-health.jsonl`, `logs/vr-r42-cn02-1100GiB/master-metrics.jsonl`, `logs/vr-r42-cn02-512GiB/client-vr-r42-cn01.jsonl`, `logs/vr-r42-cn02-512GiB/client-vr-r42-cn03.jsonl`, `logs/vr-r42-cn02-512GiB/client-vr-r42-cn06.jsonl`, `logs/vr-r42-cn02-512GiB/client-vr-r42-cn07.jsonl`, `logs/vr-r42-cn02-512GiB/client-vr-r42-cn08.jsonl`, `logs/vr-r42-cn02-512GiB/client-vr-r42-cn09.jsonl`, `logs/vr-r42-cn02-512GiB/client-vr-r42-cn10.jsonl`, `logs/vr-r42-cn02-512GiB/client-vr-r42-cn11.jsonl`, `logs/vr-r42-cn02-512GiB/client-vr-r42-cn12.jsonl`, `logs/vr-r42-cn02-512GiB/client-vr-r42-cn13.jsonl`, `logs/vr-r42-cn02-512GiB/client-vr-r42-cn15.jsonl`, `logs/vr-r42-cn02-512GiB/client-vr-r42-cn16.jsonl`, `logs/vr-r42-cn02-512GiB/client-vr-r42-cn17.jsonl`, `logs/vr-r42-cn02-512GiB/client-vr-r42-cn18.jsonl`, `logs/vr-r42-cn02-512GiB/donor-health.jsonl`, `logs/vr-r42-cn02-512GiB/external-health.jsonl`, `logs/vr-r42-cn02-512GiB/master-metrics.jsonl`, `logs/vr-r42-cn05-1100GiB/client-vr-r42-cn01.jsonl`, `logs/vr-r42-cn05-1100GiB/client-vr-r42-cn03.jsonl`, `logs/vr-r42-cn05-1100GiB/client-vr-r42-cn06.jsonl`, `logs/vr-r42-cn05-1100GiB/client-vr-r42-cn07.jsonl`, `logs/vr-r42-cn05-1100GiB/client-vr-r42-cn08.jsonl`, `logs/vr-r42-cn05-1100GiB/client-vr-r42-cn09.jsonl`, `logs/vr-r42-cn05-1100GiB/client-vr-r42-cn10.jsonl`, `logs/vr-r42-cn05-1100GiB/client-vr-r42-cn11.jsonl`, `logs/vr-r42-cn05-1100GiB/client-vr-r42-cn12.jsonl`, `logs/vr-r42-cn05-1100GiB/client-vr-r42-cn13.jsonl`, `logs/vr-r42-cn05-1100GiB/client-vr-r42-cn15.jsonl`, `logs/vr-r42-cn05-1100GiB/client-vr-r42-cn16.jsonl`, `logs/vr-r42-cn05-1100GiB/client-vr-r42-cn17.jsonl`, `logs/vr-r42-cn05-1100GiB/client-vr-r42-cn18.jsonl`, `logs/vr-r42-cn05-1100GiB/donor-health.jsonl`, `logs/vr-r42-cn05-1100GiB/external-health.jsonl`, `logs/vr-r42-cn05-1100GiB/master-metrics.jsonl`, `logs/vr-r42-cn05-512GiB/client-vr-r42-cn01.jsonl`, `logs/vr-r42-cn05-512GiB/client-vr-r42-cn03.jsonl`, `logs/vr-r42-cn05-512GiB/client-vr-r42-cn06.jsonl`, `logs/vr-r42-cn05-512GiB/client-vr-r42-cn07.jsonl`, `logs/vr-r42-cn05-512GiB/client-vr-r42-cn08.jsonl`, `logs/vr-r42-cn05-512GiB/client-vr-r42-cn09.jsonl`, `logs/vr-r42-cn05-512GiB/client-vr-r42-cn10.jsonl`, `logs/vr-r42-cn05-512GiB/client-vr-r42-cn11.jsonl`, `logs/vr-r42-cn05-512GiB/client-vr-r42-cn12.jsonl`, `logs/vr-r42-cn05-512GiB/client-vr-r42-cn13.jsonl`, `logs/vr-r42-cn05-512GiB/client-vr-r42-cn15.jsonl`, `logs/vr-r42-cn05-512GiB/client-vr-r42-cn16.jsonl`, `logs/vr-r42-cn05-512GiB/client-vr-r42-cn17.jsonl`, `logs/vr-r42-cn05-512GiB/client-vr-r42-cn18.jsonl`, `logs/vr-r42-cn05-512GiB/donor-health.jsonl`, `logs/vr-r42-cn05-512GiB/external-health.jsonl`, `logs/vr-r42-cn05-512GiB/master-metrics.jsonl`
Replica records contain per-key address/size/endpoint. Compare them with donor registration base and max_mr_size in native logs before claiming a second MR or NUMA region was exercised. A 1100 GiB registration with a small working set does not establish that coverage.
Health records contain local PID/RSS, cgroup memory/OOM data, node meminfo and raw IB counters; compare first/last values per process and NIC. Missing Linux counters are empty or null, not zeros.
Mooncake's native setup holds the Python GIL, so local health sampling pauses during registration; startup samples do not continuously observe that interval. Kernel access failures are recorded in inventory JSON.
Native stdout/stderr supplies RDMA errors and registration details; status files supply process exit codes. Missing completion/status records make a case incomplete even if recorded batches succeeded.
No DSight/dashboard was used: per-call JSONL, TCP probes, native logs and local memory/IB counters directly test peer availability and transport correctness. The [slurm-job-sizing skill](../../../src/srtctl/dsight/skills/slurm-job-sizing/SKILL.md) guides the short bounded diagnostic; it does not turn this into a serving benchmark.

Run metadata (`metadata.json`):
```json
{
  "job_id": "5431",
  "image": "/home/_shared/tensorrt-llm-release-arm64-f1bdd25-user_imant_glm5-rubin-30428.sqsh",
  "nodes": "vr-r42-cn[03,17-18,02,06,11,08,16,15,10,05,13,12,01,09,07]",
  "readers": "vr-r42-cn03,vr-r42-cn17,vr-r42-cn18,vr-r42-cn06,vr-r42-cn11,vr-r42-cn08,vr-r42-cn16,vr-r42-cn15,vr-r42-cn10,vr-r42-cn13,vr-r42-cn12,vr-r42-cn01,vr-r42-cn09,vr-r42-cn07",
  "seconds": 120,
  "batch_size": 512,
  "workers": 2,
  "page_bytes": 2006016,
  "walltime": "00:25:00",
  "body_budget_seconds": 1320,
  "sizing_skill": "src/srtctl/dsight/skills/slurm-job-sizing/SKILL.md"
}
```

Status `logs/inventory-container.exit`: `0`

Status `logs/inventory-host.exit`: `0`

Status `logs/vr-r42-cn02-1100GiB/bootstrap.exit`: `0`

Status `logs/vr-r42-cn02-1100GiB/client.exit`: `0`

Status `logs/vr-r42-cn02-1100GiB/donor.exit`: `0`

Status `logs/vr-r42-cn02-1100GiB/inventory-container.exit`: `0`

Status `logs/vr-r42-cn02-1100GiB/inventory-host.exit`: `0`

Status `logs/vr-r42-cn02-1100GiB/master.exit`: `0`

Status `logs/vr-r42-cn02-512GiB/bootstrap.exit`: `0`

Status `logs/vr-r42-cn02-512GiB/client.exit`: `0`

Status `logs/vr-r42-cn02-512GiB/donor.exit`: `0`

Status `logs/vr-r42-cn02-512GiB/inventory-container.exit`: `0`

Status `logs/vr-r42-cn02-512GiB/inventory-host.exit`: `0`

Status `logs/vr-r42-cn02-512GiB/master.exit`: `0`

Status `logs/vr-r42-cn05-1100GiB/bootstrap.exit`: `0`

Status `logs/vr-r42-cn05-1100GiB/client.exit`: `0`

Status `logs/vr-r42-cn05-1100GiB/donor.exit`: `0`

Status `logs/vr-r42-cn05-1100GiB/inventory-container.exit`: `0`

Status `logs/vr-r42-cn05-1100GiB/inventory-host.exit`: `0`

Status `logs/vr-r42-cn05-1100GiB/master.exit`: `0`

Status `logs/vr-r42-cn05-512GiB/bootstrap.exit`: `0`

Status `logs/vr-r42-cn05-512GiB/client.exit`: `0`

Status `logs/vr-r42-cn05-512GiB/donor.exit`: `0`

Status `logs/vr-r42-cn05-512GiB/inventory-container.exit`: `0`

Status `logs/vr-r42-cn05-512GiB/inventory-host.exit`: `0`

Status `logs/vr-r42-cn05-512GiB/master.exit`: `0`
