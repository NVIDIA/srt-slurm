#!/bin/bash
set -euo pipefail
run_dir=${1:?Run directory is required}
master_pid= diagnostic_pid=

stop_child() {
    local pid=$1 label=$2 grace=$3 deadline child_rc=0
    [[ -n $pid ]] || return 0
    kill -TERM "$pid" 2>/dev/null || true
    deadline=$((SECONDS + grace))
    while kill -0 "$pid" 2>/dev/null && (( SECONDS < deadline )); do sleep 1; done
    if kill -0 "$pid" 2>/dev/null; then
        printf '%s did not stop within %s seconds; killing owned PID %s.\n' "$label" "$grace" "$pid" >&2
        kill -KILL "$pid" 2>/dev/null || true
        cleanup_failed=1
    fi
    wait "$pid" 2>/dev/null || child_rc=$?
    if (( child_rc != 0 && child_rc != 143 )); then
        printf '%s exited with code %s during shutdown.\n' "$label" "$child_rc" >&2
        cleanup_failed=1
    fi
}
cleanup() {
    local rc=$?
    trap - EXIT
    trap '' INT TERM
    set +e
    cleanup_failed=0
    stop_child "$diagnostic_pid" diagnostics 60
    stop_child "$master_pid" master 10
    if (( cleanup_failed != 0 && rc == 0 )); then rc=1; fi
    printf 'exit_code=%s cleanup_failed=%s\n' "$rc" "$cleanup_failed" \
        > "$run_dir/logs/shutdown.txt"
    exit "$rc"
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM

# Retain Slurm allocation variables for the cgroup/environment evidence.
for name in $(compgen -e); do
    case "$name" in PMIX_*|PMI_*|OMPI_*|MPI_*|OPAL_*|PRTE_*|HYDRA_*|I_MPI_*) unset "$name" ;; esac
done
unset MC_USE_NVLINK_IPC MC_TE_FILTERS MC_ENABLE_DEST_DEVICE_AFFINITY MC_FORCE_TCP
export CUDA_VISIBLE_DEVICES=0,1,2,3
export MC_MS_AUTO_DISC=0 MC_USE_TENT=0 MC_USE_TEV1=0 MOONCAKE_STORE_BACKEND=cpp
export GLOG_logtostderr=1 GLOG_minloglevel=0 GLOG_v=0 PYTHONUNBUFFERED=1
export PIP_NO_INDEX=1 PIP_DISABLE_PIP_VERSION_CHECK=1
export SRT_MOONCAKE_EGM_WHEEL_DIR=/egm-wheels
export PYTHONPATH="$run_dir${PYTHONPATH:+:$PYTHONPATH}"

timeout --signal=TERM --kill-after=10s "${MC_EGM_SETUP_TIMEOUT}s" \
    bash "$run_dir/configs/setup_mooncake_egm.sh" --mooncake-only \
    > "$run_dir/logs/setup.log" 2>&1
{
    hostname
    timeout --signal=TERM --kill-after=2s 10s \
        nvidia-smi --query-gpu=index,uuid,pci.bus_id,name,memory.total,driver_version --format=csv || true
    timeout --signal=TERM --kill-after=2s 10s nvidia-smi topo -m || true
    timeout --signal=TERM --kill-after=2s 10s nvidia-smi -q || true
    if command -v numactl >/dev/null; then
        timeout --signal=TERM --kill-after=2s 5s numactl --hardware || true
    fi
    ls -l /dev/nvidia-caps-imex-channels/ || true
} > "$run_dir/logs/container-hardware.txt" 2>&1
timeout --signal=TERM --kill-after=2s 15s \
    python3 -m tools.mooncake_egm_reclaim inventory --output "$run_dir/logs/container-before.json" \
    > "$run_dir/logs/container-inventory-errors.log" 2>&1 || \
    printf 'Container inventory failed; see container-inventory-errors.log.\n' >&2

# Allocate two ephemeral listeners on this exclusive node; no port-range scan.
python3 - "$run_dir" <<'PY'
import json
import os
import socket
import sys
from contextlib import ExitStack
from pathlib import Path

run_dir = Path(sys.argv[1])
with ExitStack() as stack:
    listeners = [stack.enter_context(socket.socket()) for _ in range(2)]
    for listener in listeners:
        listener.bind(("0.0.0.0", 0))
    rpc, metrics = [listener.getsockname()[1] for listener in listeners]
hostname = socket.gethostname()
config = {"master_server_address": f"{socket.gethostbyname(hostname)}:{rpc}",
          "provider_hostname": hostname, "metrics_port": metrics}
temporary = run_dir / ".master-config.tmp"
temporary.write_text(json.dumps(config, indent=2) + "\n")
os.replace(temporary, run_dir / "master-config.json")
(run_dir / "master-ports").write_text(f"{rpc} {metrics}\n")
PY
read -r master_port metrics_port < "$run_dir/master-ports"
python3 -m mooncake.cli --rpc_port="$master_port" --metrics_port="$metrics_port" \
    --default_kv_lease_ttl=60000 --eviction_ratio=0.02 \
    > "$run_dir/logs/master.log" 2>&1 &
master_pid=$!
python3 - "$master_port" "$MC_EGM_READY_TIMEOUT" "$master_pid" <<'PY'
import os
import socket
import sys
import time

deadline = time.monotonic() + int(sys.argv[2])
while time.monotonic() < deadline:
    os.kill(int(sys.argv[3]), 0)
    try:
        with socket.create_connection(("127.0.0.1", int(sys.argv[1])), timeout=1):
            break
    except OSError:
        time.sleep(0.25)
else:
    raise SystemExit("Mooncake master RPC readiness timed out; see logs/master.log")
PY
kill -0 "$master_pid"
diagnostic_rc=0
# A controlled allocation error is diagnostic evidence; the helper distinguishes
# completed cases from timeouts, missing results or unconfirmed donor cleanup.
timeout --signal=TERM --kill-after=45s "$((MC_EGM_RECLAIM_BUDGET + 30))s" \
    python3 -m tools.mooncake_egm_reclaim run \
    --config "$run_dir/master-config.json" --output-dir "$run_dir/logs/reclaim" \
    --pool-size "$MC_EGM_RECLAIM_POOL_SIZE" --cases "$MC_EGM_RECLAIM_CASES" \
    --timeout-seconds "$MC_EGM_RECLAIM_TIMEOUT" --budget-seconds "$MC_EGM_RECLAIM_BUDGET" \
    --sample-interval "$MC_EGM_RECLAIM_SAMPLE_INTERVAL" --hold-seconds "$MC_EGM_RECLAIM_HOLD_SECONDS" \
    --chunk-size "$MC_EGM_RECLAIM_CHUNK_SIZE" > "$run_dir/logs/reclaim.log" 2>&1 &
diagnostic_pid=$!
wait "$diagnostic_pid" || diagnostic_rc=$?
diagnostic_pid=
kill -0 "$master_pid"
printf 'Reclamation diagnostic helper exit code: %s\n' "$diagnostic_rc"
exit "$diagnostic_rc"
