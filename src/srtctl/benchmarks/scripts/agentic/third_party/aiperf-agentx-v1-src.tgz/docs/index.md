---
# SPDX-FileCopyrightText: Copyright (c) 2025-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
sidebar-title: Welcome to AIPerf Documentation
---

# Welcome to AIPerf Documentation

AIPerf is a package for performance testing AI models.

## Overview

- Explore the documentation using the navigation menu.
- See the Development page for contributing and setup instructions.

## Quick Start

1. Install dependencies.
2. Run the CLI or use the Python API.

For details, see the rest of the documentation.
