# SPDX-FileCopyrightText: Copyright (c) 2025 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

from datetime import datetime
from typing import ClassVar

from pydantic import ConfigDict, Field

from aiperf.common.config import UserConfig
from aiperf.common.models.base_models import AIPerfBaseModel
from aiperf.common.models.branch_stats import BranchStats
from aiperf.common.models.error_models import ErrorDetailsCount

# =============================================================================
# JSON Metric Result
# =============================================================================


class JsonMetricResult(AIPerfBaseModel):
    """The result values of a single metric for JSON export.

    NOTE:
    The shape of this model originates from GenAI-Perf JSON output for
    downstream-tool compatibility. New fields may be added when AIPerf
    surfaces information GenAI-Perf does not (e.g. `count`, `sum` added in
    schema 1.1). When adding a field, bump `JsonExportData.SCHEMA_VERSION`
    and document the field in `docs/reference/json-export-schema.md`. Do
    not remove or rename existing fields without a matching schema bump.
    """

    unit: str = Field(description="The unit of the metric, e.g. 'ms' or 'requests/sec'")
    avg: float | None = None
    p1: float | None = None
    p5: float | None = None
    p10: float | None = None
    p25: float | None = None
    p50: float | None = None
    p75: float | None = None
    p90: float | None = None
    p95: float | None = None
    p99: float | None = None
    min: int | float | None = None
    max: int | float | None = None
    std: float | None = None
    count: int | None = Field(
        default=None,
        description=(
            "Number of records contributing to this metric's distribution. "
            "Present only for record-type metrics; omitted for derived/aggregate "
            "scalar metrics where the count would trivially be 1 and risks being "
            "misread as the request count."
        ),
    )
    sum: int | float | None = Field(
        default=None,
        description=(
            "Sum of all metric values across records. Present for record-type "
            "metrics with at least one observation; absent for derived/aggregate "
            "metrics whose value is itself the computed total or rate."
        ),
    )


# =============================================================================
# Telemetry Export Data
# =============================================================================


class TelemetrySummary(AIPerfBaseModel):
    """Summary information for telemetry collection."""

    endpoints_configured: list[str] | None = None
    endpoints_successful: list[str] | None = None
    start_time: datetime
    end_time: datetime


class GpuSummary(AIPerfBaseModel):
    """Summary of GPU telemetry data."""

    gpu_index: int
    gpu_name: str
    gpu_uuid: str
    hostname: str | None
    namespace: str | None = None
    pod_name: str | None = None
    metrics: dict[str, JsonMetricResult]  # metric_key -> {stat_key -> value}


class EndpointData(AIPerfBaseModel):
    """Data for a single endpoint."""

    gpus: dict[str, GpuSummary]


class TelemetryExportData(AIPerfBaseModel):
    """Telemetry data structure for JSON export."""

    summary: TelemetrySummary
    endpoints: dict[str, EndpointData]
    error_summary: list[ErrorDetailsCount] | None = Field(
        default=None,
        description="A list of the unique error details and their counts",
    )


# =============================================================================
# Timeslice Export Data
# =============================================================================


class TimesliceData(AIPerfBaseModel):
    """Data for a single timeslice.

    Contains metrics for one time slice with dynamic metric fields
    added via Pydantic's extra="allow" setting.

    Field semantics for ``start_ns`` / ``end_ns`` / ``is_complete`` mirror
    ``server_metrics_models.BaseTimeslice`` so inference and server-metrics
    timeslice exports share the same wire format. ``start_ns`` and ``end_ns``
    are nullable in this wire model only as a Pydantic concession; in
    practice the exporter always populates both from the source
    :class:`TimesliceResult`. Partial timeslices (typically the final slice
    when the run ends mid-window) are flagged via ``is_complete=False`` and
    should be excluded from aggregate statistics to avoid skewing rate
    calculations.

    Slice ordering is conveyed by position in the parent ``timeslices`` array;
    no explicit index field is emitted (matches the BaseTimeslice shape).
    """

    model_config = ConfigDict(extra="allow")

    start_ns: int | None = Field(
        default=None,
        description="Timeslice start timestamp in nanoseconds",
    )
    end_ns: int | None = Field(
        default=None,
        description="Timeslice end timestamp in nanoseconds",
    )
    is_complete: bool | None = Field(
        default=None,
        description="False for partial timeslices (typically the final slice). "
        "None or True for complete timeslices covering the full configured duration. "
        "Partial slices should be excluded from aggregate statistics. "
        "None by default to save space in JSON exports (treated as complete).",
    )


class TimesliceCollectionExportData(AIPerfBaseModel):
    """Export data for all timeslices in a single file.

    Contains an array of timeslice data objects with metadata.
    """

    timeslices: list[TimesliceData]
    input_config: UserConfig | None = None


# =============================================================================
# Main JSON Export Data
# =============================================================================


class JsonExportData(AIPerfBaseModel):
    """Summary data to be exported to a JSON file.

    NOTE:
    This model has been designed to mimic the structure of the GenAI-Perf JSON output
    as closely as possible. Be careful when modifying this model to not break the
    compatibility with the GenAI-Perf JSON output.
    """

    # NOTE: The extra="allow" setting is needed to allow additional metrics not defined in this class
    #       to be added to the export data. It is also already set in the AIPerfBaseModel,
    #       but we are setting it here to guard against base model changes.
    model_config = ConfigDict(extra="allow")

    # Increment on breaking changes to the export structure
    SCHEMA_VERSION: ClassVar[str] = "1.2"

    schema_version: str | None = Field(
        default=None,
        description="Schema version for this export format (for backward compatibility)",
    )
    aiperf_version: str | None = Field(
        default=None,
        description="AIPerf version that generated this export (for backward compatibility)",
    )
    benchmark_id: str | None = Field(
        default=None,
        description="Unique identifier for this benchmark run (for backward compatibility)",
    )
    request_throughput: JsonMetricResult | None = None
    request_latency: JsonMetricResult | None = None
    request_count: JsonMetricResult | None = None
    time_to_first_token: JsonMetricResult | None = None
    time_to_second_token: JsonMetricResult | None = None
    inter_token_latency: JsonMetricResult | None = None
    output_token_throughput: JsonMetricResult | None = None
    output_token_throughput_per_user: JsonMetricResult | None = None
    output_sequence_length: JsonMetricResult | None = None
    input_sequence_length: JsonMetricResult | None = None
    goodput: JsonMetricResult | None = None
    good_request_count: JsonMetricResult | None = None
    output_token_count: JsonMetricResult | None = None
    reasoning_token_count: JsonMetricResult | None = None
    min_request_timestamp: JsonMetricResult | None = None
    max_response_timestamp: JsonMetricResult | None = None
    inter_chunk_latency: JsonMetricResult | None = None
    total_output_tokens: JsonMetricResult | None = None
    total_reasoning_tokens: JsonMetricResult | None = None
    benchmark_duration: JsonMetricResult | None = None
    total_isl: JsonMetricResult | None = None
    total_osl: JsonMetricResult | None = None
    error_request_count: JsonMetricResult | None = None
    error_isl: JsonMetricResult | None = None
    total_error_isl: JsonMetricResult | None = None
    telemetry_data: TelemetryExportData | None = None
    input_config: UserConfig | None = None
    was_cancelled: bool | None = None
    error_summary: list[ErrorDetailsCount] | None = None
    start_time: datetime | None = None
    end_time: datetime | None = None
    branch_stats: BranchStats | None = Field(
        default=None,
        description="Aggregate subagent orchestration counters for DAG-shaped runs "
        "(children spawned/completed/errored, parents suspended/resumed). "
        "None when the run did not spawn any subagents.",
    )
    warmup_metrics: dict[str, JsonMetricResult] | None = Field(
        default=None,
        description="Metrics computed from warmup-phase requests only. Profiling "
        "metrics remain in the top-level metric fields.",
    )
