# SPDX-FileCopyrightText: Copyright (c) 2025-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

import asyncio
import contextlib
import multiprocessing
import os
import platform
import signal
import sys
import uuid
import warnings

from aiperf.common.config import ServiceConfig, UserConfig
from aiperf.common.environment import Environment
from aiperf.plugin.enums import ServiceType

# Suppress ZMQ RuntimeWarning about dropped messages during shutdown.
# This is expected behavior when async tasks are cancelled while ZMQ messages are in-flight.
warnings.filterwarnings(
    "ignore",
    message=".*Future.*completed while awaiting.*A message has been dropped.*",
    category=RuntimeWarning,
    module="zmq._future",
)


def bootstrap_and_run_service(
    service_type: ServiceType,
    *,
    service_config: ServiceConfig | None = None,
    user_config: UserConfig | None = None,
    service_id: str | None = None,
    log_queue: "multiprocessing.Queue | None" = None,
    controller_pid: int | None = None,
    **kwargs,
):
    """Bootstrap the service and run it.

    This function will load the service configuration,
    create an instance of the service, and run it.

    Args:
        service_type: The type of the service to run.
        service_config: The service configuration to use. If not provided, the service
            configuration will be loaded from the environment variables.
        user_config: The user configuration to use. If not provided, the user configuration
            will be loaded from the environment variables.
        log_queue: Optional multiprocessing queue for child process logging. If provided,
            the child process logging will be set up.
        controller_pid: PID of the launching SystemController, used to arm the
            child's parent-death guard (see ``_install_parent_death_signal``).
        kwargs: Additional keyword arguments to pass to the service constructor.
    """
    # Ignore SIGINT and SIGTERM in child processes. SIGINT is ignored so only
    # the parent handles Ctrl+C. SIGTERM is ignored because graceful shutdown is
    # handled via the message bus (ShutdownCommand); process.terminate() is only
    # called after the message bus path has already timed out, and the manager
    # falls through to SIGKILL after the join timeout anyway. Ignoring SIGTERM
    # prevents SIGSEGV crashes that occur when SIGTERM arrives while C extension
    # code (uvloop, zmq, aiohttp, orjson) is executing.
    if multiprocessing.parent_process() is not None:
        # Arm the parent-death guard FIRST, before anything else can leak time,
        # so a SIGKILL'd controller cannot orphan this process. SIGKILL is the
        # only viable death signal here precisely because SIGTERM is ignored
        # just below.
        _install_parent_death_signal(controller_pid)
        signal.signal(signal.SIGINT, signal.SIG_IGN)
        signal.signal(signal.SIGTERM, signal.SIG_IGN)

    # Diagnostic stack-dump signal — `kill -USR1 <pid>` writes the full
    # Python traceback for every thread in the process to stderr (which
    # ends up in the worker's per-service log file). Crucial for
    # debugging hangs in non-cooperative subprocess pools where py-spy
    # isn't installed on the runner. Never attached on Windows.
    import faulthandler

    if hasattr(signal, "SIGUSR1"):
        # Already registered, or in a context where signal handlers can't
        # be installed (best-effort). AttributeError covers test harnesses
        # that wrap stderr in a stream without fileno() (e.g. TeeStream).
        with contextlib.suppress(ValueError, RuntimeError, AttributeError):
            faulthandler.register(signal.SIGUSR1, all_threads=True, chain=False)

    from aiperf.plugin import plugins
    from aiperf.plugin.enums import PluginType

    ServiceClass = plugins.get_class(PluginType.SERVICE, service_type)
    service_metadata = plugins.get_service_metadata(service_type)
    if not service_id:
        service_id = (
            f"{service_type}_{uuid.uuid4().hex[:8]}"
            if service_metadata.replicable
            else str(service_type)
        )

    # Load the service configuration
    if service_config is None:
        from aiperf.common.config.loader import load_service_config

        service_config = load_service_config()

    # Load the user configuration
    if user_config is None:
        from aiperf.common.config.loader import load_user_config

        user_config = load_user_config()

    async def _run_service():
        # Disable health server in child processes to prevent port conflicts.
        # Multiple child processes on the same host cannot bind to the same port.
        # The main process (SystemController) handles health probes for local mode.
        is_child_process = multiprocessing.parent_process() is not None
        if is_child_process:
            Environment.SERVICE.HEALTH_ENABLED = False

        if Environment.DEV.ENABLE_YAPPI:
            _start_yappi_profiling()

        if service_metadata.disable_gc:
            # Disable garbage collection in child processes to prevent unpredictable latency spikes.
            # Only required in timing critical services such as Worker and TimingManager.
            import gc

            for _ in range(3):  # Run 3 times to ensure all objects are collected
                gc.collect()
            gc.freeze()
            gc.set_threshold(0)
            gc.disable()

        # Load and apply custom GPU metrics in child process
        if user_config.gpu_telemetry_metrics_file:
            from aiperf.gpu_telemetry import constants
            from aiperf.gpu_telemetry.metrics_config import MetricsConfigLoader

            loader = MetricsConfigLoader()
            custom_metrics, new_dcgm_mappings = loader.build_custom_metrics_from_csv(
                custom_csv_path=user_config.gpu_telemetry_metrics_file
            )

            constants.GPU_TELEMETRY_METRICS_CONFIG.extend(custom_metrics)
            constants.DCGM_TO_FIELD_MAPPING.update(new_dcgm_mappings)

        service = ServiceClass(
            service_config=service_config,
            user_config=user_config,
            service_id=service_id,
            **kwargs,
        )

        from aiperf.common.logging import setup_child_process_logging

        setup_child_process_logging(
            log_queue, service.service_id, service_config, user_config
        )

        # NOTE: Prevent child processes from accessing parent's terminal on macOS.
        # This solves the macOS terminal corruption issue with Textual UI where child
        # processes inherit terminal file descriptors and interfere with Textual's
        # terminal management, causing ASCII garbage and freezing when mouse events occur.
        # Only apply this in spawned child processes, NOT in the main process where Textual runs.
        if platform.system() == "Darwin" and is_child_process:
            _redirect_stdio_to_devnull()

        # Initialize global RandomGenerator for reproducible random number generation
        from aiperf.common import random_generator as rng

        # Always reset and then initialize the global random generator to ensure a clean state
        rng.reset()
        rng.init(user_config.input.random_seed)

        try:
            await service.initialize()
            await service.start()
            await service.stopped_event.wait()
        except Exception as e:
            service.exception(f"Unhandled exception in service: {e}")

        if Environment.DEV.ENABLE_YAPPI:
            _stop_yappi_profiling(service.service_id, user_config)

    with contextlib.suppress(asyncio.CancelledError):
        if not Environment.SERVICE.DISABLE_UVLOOP:
            import uvloop

            uvloop.run(_run_service())
        else:
            asyncio.run(_run_service())


def _install_parent_death_signal(controller_pid: int | None = None) -> None:
    """Ask the kernel to SIGKILL this process when the controller dies (Linux only).

    The SystemController launches each service as a ``daemon=True`` child, which
    only reaps children when the parent exits cleanly via Python's ``atexit``
    hook. A SIGKILL'd, OOM-killed, or crashed controller never runs that hook,
    so the services orphan, reparent to init/systemd, and leak RAM
    indefinitely. ``PR_SET_PDEATHSIG`` is a kernel-level backstop that fires
    regardless of how the parent dies.

    SIGKILL (not SIGTERM) is mandatory: child processes ignore SIGTERM to avoid
    C-extension SIGSEGV (see caller), so a catchable death signal would simply
    be ignored and the orphan would survive anyway. Since the parent is already
    gone by the time this fires, there is nothing left to shut down gracefully.

    ``controller_pid`` is the SystemController PID captured at launch time. It is
    the ground truth for "who is our parent", which matters because
    PR_SET_PDEATHSIG only delivers for deaths that occur *after* it is armed: if
    the controller died in the launch/import window before this runs, the child
    has already reparented to a subreaper (systemd ``--user``, not always PID 1)
    and the signal would never fire. Comparing the live ``getppid()`` against the
    captured controller PID detects that race under both fork and spawn start
    methods. When ``None`` (e.g. tests), it falls back to a ``getppid()``
    snapshot, which is still correct under fork when the controller is alive.

    Best-effort: any failure to arm the guard is non-fatal (the process simply
    falls back to the pre-existing ``daemon=True`` behavior).
    """
    if platform.system() != "Linux":
        return

    import ctypes

    PR_SET_PDEATHSIG = 1
    expected_ppid = controller_pid if controller_pid is not None else os.getppid()
    try:
        libc = ctypes.CDLL("libc.so.6", use_errno=True)
        if libc.prctl(PR_SET_PDEATHSIG, signal.SIGKILL, 0, 0, 0) != 0:
            return
    except (OSError, AttributeError):
        return

    # If our parent is no longer the controller, it already died and we
    # reparented during the race window — the death signal was missed forever,
    # so exit now rather than orphan.
    if os.getppid() != expected_ppid:
        os._exit(1)


def _redirect_stdio_to_devnull() -> None:
    """Redirect stdin/stdout/stderr to /dev/null for macOS child processes.

    Prevents child processes from accessing the parent's terminal, which causes
    Textual UI corruption (ASCII garbage and freezes from inherited terminal FDs).
    """
    # Redirect at the OS level so spawned grandchild processes (e.g.
    # ProcessPoolExecutor workers via 'spawn' context) inherit safe FDs
    # rather than the terminal FDs that Textual manages.
    # Python-level reassignment alone (sys.stdout = ...) is not enough
    # because spawned processes create fresh sys.* from inherited OS FDs.
    #
    # No error handling: if /dev/null can't be opened or dup2 fails, the
    # process is in a broken state and should crash rather than continue
    # with corrupted FDs.
    #
    # Runs inside the event loop as one of the first operations, but
    # os.open on /dev/null hits a kernel fast path (no disk I/O), so
    # the blocking calls are safe here.
    devnull_fd = os.open(os.devnull, os.O_RDWR)
    for fd in (0, 1, 2):
        os.dup2(devnull_fd, fd)
    os.close(devnull_fd)

    # Recreate Python-level streams from the redirected OS FDs.
    # closefd=False keeps FD ownership at the OS level so that if these
    # stream objects are garbage-collected (e.g. replaced by test frameworks),
    # the underlying FDs 0/1/2 stay open and the /dev/null redirect holds.
    sys.stdin = os.fdopen(0, "r", closefd=False)
    sys.stdout = os.fdopen(1, "w", closefd=False)
    sys.stderr = os.fdopen(2, "w", closefd=False)


def _start_yappi_profiling() -> None:
    """Start yappi profiling to profile AIPerf's python code."""
    try:
        import yappi

        yappi.set_clock_type("cpu")
        yappi.start()
    except ImportError as e:
        from aiperf.common.exceptions import AIPerfError

        raise AIPerfError(
            "yappi is not installed. Please install yappi to enable profiling. "
            "You can install yappi with `pip install yappi`."
        ) from e


def _stop_yappi_profiling(service_id_: str, user_config: UserConfig) -> None:
    """Stop yappi profiling and save the profile to a file."""
    import yappi

    yappi.stop()

    # Get profile stats and save to file in the artifact directory
    stats = yappi.get_func_stats()
    yappi_dir = user_config.output.artifact_directory / "yappi"
    yappi_dir.mkdir(parents=True, exist_ok=True)
    stats.save(
        str(yappi_dir / f"{service_id_}.prof"),
        type="pstat",
    )
