# SPDX-FileCopyrightText: Copyright (c) 2025-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
"""Pydantic models for plugin YAML schema validation.

Defines the structure of categories.yaml (extension points) and plugins.yaml
(implementations). Used for JSON Schema generation (IDE autocomplete/validation)
and runtime validation.

To regenerate JSON schemas: python tools/generate_plugin_artifacts.py --schemas
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field

# =============================================================================
# Plugins YAML Schema (plugins.yaml)
# =============================================================================
# These models define the structure of plugins.yaml, which registers concrete
# plugin implementations. The PluginsManifest is the root, containing category
# sections that map type names to PluginSpec entries.
# =============================================================================


class PluginsManifest(BaseModel):
    """Root model for plugins.yaml file.

    This file registers plugin implementations for AIPerf. Each top-level section
    corresponds to a category from categories.yaml and maps type names to their
    implementing classes.

    Note: Package metadata (name, version, author) comes from pyproject.toml
    via importlib.metadata, not from this file.

    Example:
    ```yaml
    schema_version: "1.0"

    endpoint:
      my_custom:
        class: my_package.endpoints.my_custom:MyCustomEndpoint
        description: Custom endpoint for my API.
        metadata:
          endpoint_path: /v1/generate
          supports_streaming: true
          produces_tokens: true
          tokenizes_input: true
          metrics_title: My Custom Metrics

    custom_dataset_loader:
      my_jsonl:
        class: my_package.dataset_loaders.my_jsonl:MyJSONLDatasetLoader
        description: Custom dataset loader for my API.
    ```
    """

    # Plugin categories are stored as additional fields
    model_config = ConfigDict(extra="allow")

    schema_version: str = Field(
        default="1.0",
        description="Version of the plugins.yaml schema format. Use '1.0' for current format.",
    )


class PluginSpec(BaseModel):
    """Specification for a plugin implementation.

    Each plugin entry maps a type name (like 'chat' or 'completions') to a Python
    class that implements the category's protocol. The type name becomes an enum
    member (e.g., EndpointType.CHAT) used for configuration and API selection.

    Example::

        chat:
          class: aiperf.endpoints.openai_chat:ChatEndpoint
          description: |
            OpenAI Chat Completions endpoint. Supports multi-modal inputs
            and streaming responses.
          metadata:
            endpoint_path: /v1/chat/completions
            supports_streaming: true
    """

    model_config = ConfigDict(populate_by_name=True)

    class_: str = Field(
        alias="class",
        description=(
            "Python class that implements this plugin entry. "
            "Use 'module.path:ClassName' format, e.g., 'aiperf.endpoints.openai_chat:ChatEndpoint'."
        ),
    )
    description: str = Field(
        default="",
        description="Brief explanation of what this plugin type does and when to use it.",
    )
    priority: int = Field(
        default=0,
        description=(
            "Conflict resolution priority. When multiple packages register the same type name, "
            "the one with higher priority wins. Use 0 for normal plugins, higher values to "
            "override built-in implementations."
        ),
    )
    metadata: dict[str, Any] | None = Field(
        default=None,
        description=(
            "Category-specific configuration for this plugin type. "
            "The allowed fields depend on the category's metadata_class in categories.yaml."
        ),
    )


# =============================================================================
# Categories YAML Schema (categories.yaml)
# =============================================================================
# These models define the structure of categories.yaml, which declares all
# extension points in AIPerf. The CategoriesManifest is the root, containing
# CategorySpec entries that define protocols, enums, and optional metadata schemas.
# =============================================================================


class CategoriesManifest(BaseModel):
    """Root model for categories.yaml file.

    This file defines all plugin extension points in AIPerf. Each category
    specifies a protocol interface and generates an enum for type selection.

    Example:
    ```yaml
    schema_version: "1.0"

    endpoint:
      protocol: aiperf.endpoints.protocols:EndpointProtocol
      metadata_class: aiperf.plugin.schema.schemas:EndpointMetadata
      enum: EndpointType
      description: HTTP endpoint handlers for LLM APIs

    service:
      protocol: aiperf.common.protocols:ServiceProtocol
      metadata_class: aiperf.plugin.schema.schemas:ServiceMetadata
      enum: ServiceType
      description: Service plugins for AIPerf.

    ...
    ```
    """

    # Categories are stored as additional fields beyond schema_version
    model_config = ConfigDict(extra="allow")

    schema_version: str = Field(
        default="1.0",
        description="Version of the categories.yaml schema format. Used for backwards compatibility.",
    )


class CategorySpec(BaseModel):
    """Specification for a plugin category (extension point).

    Categories define extension points in AIPerf where plugins can provide
    custom implementations. The protocol defines the interface, and the enum
    provides type-safe selection in configuration files and APIs.

    Example::

        endpoint:
          protocol: aiperf.endpoints.protocols:EndpointProtocol
          metadata_class: aiperf.plugin.schema.schemas:EndpointMetadata
          enum: EndpointType
          description: HTTP endpoint handlers for different LLM APIs.
    """

    protocol: str = Field(
        description=(
            "The interface that plugins in this category must implement. "
            "Use 'module.path:ClassName' format, e.g., 'aiperf.endpoints.protocols:EndpointProtocol'."
        )
    )
    metadata_class: str | None = Field(
        default=None,
        description=(
            "Optional class path for category-specific metadata. "
            "When set, plugins can include typed metadata fields validated against this schema. "
            "Use 'module.path:ClassName' format."
        ),
    )
    enum: str = Field(
        description=(
            "Name of the enum that will be auto-generated from registered plugins. "
            "This enum is used in config files and APIs to select plugin types, "
            "e.g., 'EndpointType' generates EndpointType.CHAT, EndpointType.COMPLETIONS, etc."
        )
    )
    description: str = Field(
        description="Brief explanation of what this category is for and when to use it."
    )
    internal: bool = Field(
        default=False,
        description=(
            "Set to true for infrastructure categories not meant for end users. "
            "Internal categories are hidden from documentation and plugin listings."
        ),
    )


# =============================================================================
# Plugin Metadata Classes
# =============================================================================
# These classes define typed metadata schemas for specific plugin categories.
# They are referenced by categories.yaml via the `metadata_class` field and
# used to validate the `metadata` field in plugins.yaml entries.
#
# When adding a new metadata class:
# 1. Define the Pydantic model here with Field descriptions
# 2. Reference it in categories.yaml: metadata_class: aiperf.plugin.schema.schemas:YourMetadata
# 3. Run `python tools/generate_plugin_artifacts.py --schemas` to update JSON schemas
# 4. Plugins can then include typed metadata validated against this schema
# =============================================================================


class EndpointMetadata(BaseModel):
    """Metadata schema for endpoint plugins.

    Defines API capabilities, paths, and multimodal support for endpoint implementations.
    Used by the framework to route requests, configure streaming, and enable
    multimodal inputs/outputs (images, audio, video).

    Referenced by: categories.yaml endpoint.metadata_class
    Used in: plugins.yaml endpoint entries
    """

    metrics_title: str | None = Field(
        ..., description="Display title for metrics dashboard."
    )
    endpoint_path: str | None = Field(
        ..., description="API path (e.g., /v1/chat/completions)."
    )
    streaming_path: str | None = Field(
        default=None,
        description="Streaming API path if different from the endpoint path (e.g., /generate_stream).",
    )
    service_kind: str = Field(
        default="openai",
        description="The service kind of the endpoint (used for artifact naming).",
    )
    supports_streaming: bool = Field(
        ..., description="Whether endpoint supports streaming responses."
    )
    tokenizes_input: bool = Field(
        ..., description="Whether endpoint tokenizes text inputs."
    )
    produces_tokens: bool = Field(
        ..., description="Whether endpoint produces token-based output."
    )
    supports_audio: bool = Field(
        default=False, description="Whether endpoint accepts audio input."
    )
    supports_images: bool = Field(
        default=False, description="Whether endpoint accepts image input."
    )
    supports_videos: bool = Field(
        default=False, description="Whether endpoint accepts video input."
    )
    produces_audio: bool = Field(
        default=False, description="Whether endpoint produces audio-based outputs."
    )
    produces_images: bool = Field(
        default=False, description="Whether endpoint produces image-based outputs."
    )
    produces_videos: bool = Field(
        default=False, description="Whether endpoint produces video-based outputs."
    )
    requires_polling: bool = Field(
        default=False,
        description="Whether endpoint uses async job polling (submit job, poll for status, retrieve result).",
    )
    requires_form_data: bool = Field(
        default=False,
        description=(
            "True for endpoints that require multipart/form-data (binary uploads), "
            "e.g., video_generation, image_edit. EndpointConfig consumes this flag "
            "to auto-select the request encoding."
        ),
    )
    requires_inline_media: bool = Field(
        default=False,
        description="Whether endpoint requires media URLs to be downloaded and inlined as base64 data URLs.",
    )
    consumes_system_message: bool = Field(
        default=False,
        description=(
            "Whether endpoint sends RequestInfo.system_message on the wire "
            "(e.g. a leading system role for chat, top-level instructions for "
            "responses). When False, the multi-turn loader does not hoist a "
            "leading system turn into the conversation system_message, since it "
            "would be silently dropped."
        ),
    )


class TransportMetadata(BaseModel):
    """Metadata schema for transport plugins.

    Defines network layer configuration including transport type and URL schemes.
    Used by the framework to auto-detect appropriate transport based on URL scheme.

    Referenced by: categories.yaml transport.metadata_class
    Used in: plugins.yaml transport entries
    """

    transport_type: str = Field(
        description="Transport type identifier for this transport"
    )
    url_schemes: list[str] = Field(
        default_factory=list,
        description="URL schemes this transport handles (for auto-detection and validation).",
    )


class PlotMetadata(BaseModel):
    """Metadata schema for plot plugins.

    Defines display properties and categorization for visualization handlers.
    Used by the framework to group plots and generate selection interfaces.

    Referenced by: categories.yaml plot.metadata_class
    Used in: plugins.yaml plot entries
    """

    display_name: str = Field(description="Human-readable name for UI display.")
    category: str = Field(
        description="Plot category (per_request, aggregated, combined, comparison)."
    )


class CustomDatasetLoaderMetadata(BaseModel):
    """Metadata schema for custom dataset loader plugins.

    Defines format-specific defaults for dataset loaders. When a loader specifies
    ``block_size``, it overrides the user's ``--isl-block-size`` config default,
    ensuring hash-based prompt generation uses the correct token block size for the
    trace format (e.g. 16 for Bailian, 512 for Mooncake).

    Referenced by: categories.yaml custom_dataset_loader.metadata_class
    Used in: plugins.yaml custom_dataset_loader entries
    """

    is_trace: bool = Field(
        default=False,
        description=(
            "Whether this loader handles trace-format datasets. "
            "Trace datasets use hash_ids-based prompt generation, support synthesis "
            "options, and prefer sequential sampling with fixed_schedule timing."
        ),
    )
    default_block_size: int | None = Field(
        default=None,
        ge=1,
        description=(
            "Default token block size for hash-based prompt caching. "
            "Used when the user does not explicitly set --isl-block-size. "
            "Must match the block size used to generate the trace's hash_ids "
            "(e.g. 16 for Bailian, 512 for Mooncake)."
        ),
    )
    default_prompt_corpus: str = Field(
        default="sonnet",
        description=(
            "Default synthetic prompt corpus for this loader. Applied when the "
            "user does not explicitly pass --prompt-corpus. Loaders for coding "
            "agent traces (e.g. weka_trace) override to 'coding' so reconstructed "
            "prompts resemble real tool-use content."
        ),
    )
    category: str | None = Field(
        default=None,
        description=(
            "Filter dataset rows to a specific category value. Used by custom "
            "loaders that support per-category subsets (e.g. SPEED-Bench)."
        ),
    )
    multi_turn: bool = Field(
        default=False,
        description=(
            "When true, each row becomes one Conversation with multiple Turn objects."
        ),
    )


class PublicDatasetLoaderMetadata(BaseModel):
    """Metadata schema for public dataset loader plugins.

    Referenced by: categories.yaml public_dataset_loader.metadata_class
    Used in: plugins.yaml public_dataset_loader entries
    """

    hf_dataset_name: str | None = Field(
        default=None,
        description="HuggingFace dataset identifier (e.g. 'AI-MO/NuminaMath-TIR'). Required for HF-backed loaders.",
    )
    hf_split: str = Field(
        default="train",
        description="HuggingFace dataset split to load (e.g. 'train', 'test', 'validation').",
    )
    hf_subset: str | None = Field(
        default=None,
        description="HuggingFace dataset subset/config name. Only needed for datasets with multiple configs.",
    )
    is_trace: bool = Field(
        default=False,
        description=(
            "Whether this loader handles trace-format datasets. Trace public "
            "datasets reuse hash_ids-based prompt generation, require a "
            "tokenizer, and prefer sequential sampling. Mirrors the field of "
            "the same name on CustomDatasetLoaderMetadata so trace loaders can "
            "live in either pipeline."
        ),
    )
    default_block_size: int | None = Field(
        default=None,
        ge=1,
        description=(
            "Default token block size for hash-based prompt caching. Used "
            "when the user does not explicitly set --isl-block-size. Must "
            "match the block size used to generate the trace's hash_ids."
        ),
    )
    default_prompt_corpus: str = Field(
        default="sonnet",
        description=(
            "Default synthetic prompt corpus for this loader. Applied when "
            "the user does not explicitly pass --prompt-corpus. Loaders for "
            "coding agent traces override to 'coding'."
        ),
    )
    prompt_column: str | None = Field(
        default=None,
        description="Column name containing the prompt/instruction text. Required for HFInstructionResponseDatasetLoader.",
    )
    image_column: str | None = Field(
        default=None,
        description="Column name containing the image data (PIL Image). Used for multimodal datasets.",
    )
    video_column: str | None = Field(
        default=None,
        description="Column name containing the video data (URL string or bytes dict). Used for video multimodal datasets.",
    )
    audio_column: str | None = Field(
        default=None,
        description=(
            "Column name containing audio data. Depending on loader/dataset, this can be "
            "an HF Audio dict with array/sampling_rate (decoded) or bytes/path (decode=False). "
            "Used for ASR/speech datasets."
        ),
    )
    conversation_column: str | None = Field(
        default=None,
        description="Column name containing the conversation messages array. Required for HFConversationDatasetLoader.",
    )
    message_content_key: str = Field(
        default="content",
        description="Key inside each message dict for the text content. Used with conversation_column (e.g. 'content', 'value').",
    )
    multi_turn: bool = Field(
        default=False,
        description=(
            "When true, each row becomes one Conversation with multiple Turn objects. "
            "For HFConversationDatasetLoader: user→assistant (OpenAI roles) or human→gpt "
            "(ShareGPT-style ``from`` fields) pairs."
        ),
    )
    streaming: bool = Field(
        default=False,
        description=(
            "Whether to load the HuggingFace dataset in streaming mode. "
            "Use true for large datasets (>10 GB) to avoid downloading the full dataset. "
            "Use false (default) for small datasets to leverage HF caching and len() support."
        ),
    )
    has_timing_data: bool = Field(
        default=False,
        description="Whether the loader emits timestamps suitable for fixed-schedule replay.",
    )
    prompt_template: str | None = Field(
        default=None,
        description="Python str.format() template for constructing the prompt from multiple columns (e.g. '{code}\\n\\n{change_request}'). When set, overrides prompt_column. All referenced column names must exist in the dataset.",
    )


class ServiceMetadata(BaseModel):
    """Metadata schema for service plugins.

    Defines lifecycle and runtime configuration for AIPerf distributed services.
    Used by SystemController to manage service startup order and optimize
    latency-sensitive services (timing, workers) by disabling garbage collection.

    Referenced by: categories.yaml service.metadata_class
    Used in: plugins.yaml service entries
    """

    required: bool = Field(
        description="Whether the service is required for benchmark execution."
    )
    auto_start: bool = Field(
        description="Whether the service is automatically started by the system controller."
    )
    disable_gc: bool = Field(
        default=False,
        description="Whether to disable garbage collection in the service for timing-critical operations.",
    )
    replicable: bool = Field(
        default=False,
        description="Whether the service can have multiple instances running in parallel.",
    )


class GPUTelemetryCollectorMetadata(BaseModel):
    """Config-time metadata for GPU telemetry collector plugins.

    Local collectors set ``is_local`` so ``--gpu-telemetry <name>`` is treated
    as an in-process collector keyword instead of a DCGM URL. Native binding
    validation lives on the collector class itself via ``validate_environment``
    so each implementation owns its own dependency check.

    Referenced by: categories.yaml gpu_telemetry_collector.metadata_class
    Used in: plugins.yaml gpu_telemetry_collector entries
    """

    is_local: bool = Field(
        default=False,
        description="Whether this collector runs in-process against the local host.",
    )


class RecordRoutingMetadata(BaseModel):
    """Metadata schema for record routing in accumulator and stream exporter plugins.

    Defines which record types an accumulator or stream exporter accepts. Used by
    RecordsManager to build a routing table: incoming records are dispatched to all
    accumulators and stream exporters whose record_types include the matching type.
    The role (accumulator vs stream_exporter) is determined by the plugin category.

    Referenced by: categories.yaml accumulator.metadata_class, stream_exporter.metadata_class
    Used in: plugins.yaml accumulator and stream_exporter entries
    """

    record_types: list[str] = Field(
        description=(
            "Record type identifiers this accumulator or stream exporter accepts for routing. "
            "RecordsManager dispatches incoming records to all accumulators and stream exporters "
            "whose record_types include the matching type. "
            "Values: 'metric_records', 'gpu_telemetry', 'server_metrics', 'accuracy', "
            "'network_latency', 'credit_phase_stats'."
        ),
    )


class RecordProducerMetadata(BaseModel):
    """Metadata schema for record producer plugins.

    Producers parse a record and emit one typed result on a declared record-type
    channel. RecordProcessorService groups producer outputs by this declared
    ``record_type`` (rather than runtime type-sniffing) and routes each group to
    its dedicated downstream message.

    Referenced by: categories.yaml record_processor.metadata_class
    Used in: plugins.yaml record_processor entries
    """

    record_type: str = Field(
        description="The record_type channel this producer emits onto. Values: "
        "'metric_records', 'accuracy', 'gpu_telemetry', 'server_metrics', "
        "'network_latency', 'credit_phase_stats'.",
    )


class AnalyzerMetadata(BaseModel):
    """Metadata schema for analyzer plugins.

    Analyzers run at summarize time and join across accumulators. They store no
    records; instead they declare their dependencies by KIND:

    - ``required_accumulators``: needs the LIVE accumulator instance (via
      ``SummaryContext.get_accumulator``) to run a query not present in the
      summary — e.g. energy efficiency calls ``GPUTelemetryAccumulator``'s
      windowed ``total_energy_joules`` / ``total_power_watts``.
    - ``required_summaries``: needs only the already-computed summary output
      (via ``SummaryContext.get_output``) — e.g. energy efficiency reads token
      and duration totals off the metrics accumulator's summary.

    RecordsManager runs an analyzer only when every required accumulator is
    loaded AND every required summary was produced; otherwise it is skipped
    (e.g. energy efficiency is skipped when GPU telemetry is disabled).

    Referenced by: categories.yaml analyzer.metadata_class
    Used in: plugins.yaml analyzer entries
    """

    required_accumulators: list[str] = Field(
        default_factory=list,
        description=(
            "AccumulatorType names whose LIVE instance this analyzer queries via "
            "SummaryContext.get_accumulator(). The analyzer is skipped unless all "
            "are loaded. Values: 'metric_records', 'gpu_telemetry', 'server_metrics', "
            "'accuracy', 'network_latency'."
        ),
    )

    required_summaries: list[str] = Field(
        default_factory=list,
        description=(
            "AccumulatorType names whose SUMMARY output this analyzer reads via "
            "SummaryContext.get_output(). The analyzer is skipped unless all were "
            "produced. NOTE: only the 'metric_results' summary is currently "
            "registered into SummaryContext.accumulator_outputs; side-channel "
            "accumulators (gpu_telemetry, server_metrics, accuracy, network_latency) "
            "summarize separately and are NOT available here -- depend on their LIVE "
            "instance via required_accumulators instead. Declaring one of those in "
            "required_summaries silently skips the analyzer every run."
        ),
    )


# =============================================================================
# Re-exports
# =============================================================================
# Orchestrator metadata classes live in `_orchestrator_schemas.py`; re-exported
# here so plugins.yaml references like
# ``metadata_class: aiperf.plugin.schema.schemas:ConvergenceCriterionMetadata``
# keep resolving.
from aiperf.plugin.schema._orchestrator_schemas import (  # noqa: E402
    ConvergenceCriterionMetadata,
    SearchPlannerMetadata,
)

__all__ = [
    "ConvergenceCriterionMetadata",
    "GPUTelemetryCollectorMetadata",
    "RecordRoutingMetadata",
    "SearchPlannerMetadata",
]
