# SPDX-FileCopyrightText: Copyright (c) 2025-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

from aiperf.accuracy.graders.base import BaseGrader
from aiperf.accuracy.models import GradingResult
from aiperf.common.config import UserConfig


class ExactMatchGrader(BaseGrader):
    """Grades responses by exact string matching against ground truth."""

    def __init__(self, user_config: UserConfig, **kwargs) -> None:
        super().__init__(user_config=user_config, **kwargs)

    async def grade(
        self, response_text: str, ground_truth: str, **kwargs
    ) -> GradingResult:
        raise NotImplementedError(
            "exact_match grader is not yet implemented; only 'multiple_choice' is available in this release."
        )

    def extract_answer(self, response_text: str, **kwargs) -> str:
        raise NotImplementedError(
            "exact_match grader is not yet implemented; only 'multiple_choice' is available in this release."
        )
