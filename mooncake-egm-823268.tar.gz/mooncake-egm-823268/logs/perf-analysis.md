# Mooncake remote EGM diagnostic

Status: **PASS**; launcher exit code: `0`.
Native NVLink memcpy log observed: `True` (source: `client.log`).
Requested verified samples complete: `True` (source: `client-results.json`).
Pinned host source/destination buffers verified: `True` (source: `client-results.json` CUDA pointer attributes).
Report generated: 2026-10-22T04:07:20.690208+00:00.

## Goal and controls

Test whether pinned host buffers can put/get and fully verify data in the other node's EGM host-memory Store pool using the explicitly selected Mooncake NVLink transport. The client owns zero global Store capacity and zero internal Store local-buffer capacity. Each returned replica must be COMPLETE memory on the provider node. Both client payload buffers are pinned CPU tensors and must have CUDA pointer type `cudaMemoryTypeHost`; managed and GPU payload buffers are rejected. GPU IDs select CUDA submission devices only. CUDA contexts, streams and mapping metadata may still use GPU resources; this test does not require zero driver/context HBM consumption.

Baseline: none; this reduced correctness diagnostic does not compare transports or enforce a bandwidth SLO. The small payload sweep measures synchronous API latency, including RPC/control overhead; it does not measure NVLink saturation. No RDMA/TCP data transport is requested. TCP control-plane RPC is still used.

## Configuration and hardware

- Slurm job: `823268`; two allocated nodes.
- Client: `hecate0146.hecate.clusters.nvidia.com`; provider: `hecate0145.hecate.clusters.nvidia.com`.
- CUDA submission GPU IDs/names: `[0, 1, 2, 3]` / `{'0': 'NVIDIA Graphics Device', '1': 'NVIDIA Graphics Device', '2': 'NVIDIA Graphics Device', '3': 'NVIDIA Graphics Device'}`.
- Payload allocation: `pinned_host`; verified buffer records: `8` / `8`.
- PyTorch/CUDA: `2.14.0a0+4fdf77b940.nvinternal.rubin.0.8dev` / `13.5`; wheel packages: `{'mooncake-transfer-engine-cuda13': '0.3.14.dev20261021'}`.
- Payload sizes (B): `[65536, 1048576, 16777216, 67108864]`; concurrency: one synchronous transfer; warmup/measurement iterations per GPU/size: `2` / `10`.
- Client window UTC: `2026-10-22T04:06:46.705662+00:00` to `2026-10-22T04:07:01.640361+00:00`; wall duration: `14.92851244999838` s.

## Measurements

TTFT p50/p95/p99 (ms), ITL p50/p99 (ms/token), input/output/total throughput (tokens/s), and agentic Pareto/SLO metrics: **N/A**. This workload transfers bytes and runs no inference requests, model, tokenizer or agentic conversations.

Fully verified transfers: 192 put/get pairs including warmup; 160 measured pairs. Every successful sample compares the complete CPU destination with the deterministic CPU source. Payload generation and equality verification are outside timed intervals.

| GPU | Payload B | API | Samples | p50 ms | p95 ms | p99 ms | Payload GiB/s |
| --- | ---: | --- | ---: | ---: | ---: | ---: | ---: |
| 0 | 65536 | put | 10 | 0.705 | 3.022 | 4.453 | 0.054 |
| 0 | 65536 | get | 10 | 0.344 | 0.676 | 0.807 | 0.152 |
| 0 | 1048576 | put | 10 | 0.647 | 0.711 | 0.714 | 1.531 |
| 0 | 1048576 | get | 10 | 0.380 | 0.393 | 0.396 | 2.619 |
| 0 | 16777216 | put | 10 | 1.134 | 1.476 | 1.499 | 13.327 |
| 0 | 16777216 | get | 10 | 0.547 | 0.692 | 0.704 | 28.216 |
| 0 | 67108864 | put | 10 | 1.715 | 1.832 | 1.840 | 36.832 |
| 0 | 67108864 | get | 10 | 0.969 | 1.075 | 1.083 | 66.127 |
| 1 | 65536 | put | 10 | 0.551 | 0.842 | 0.943 | 0.101 |
| 1 | 65536 | get | 10 | 0.274 | 0.453 | 0.473 | 0.204 |
| 1 | 1048576 | put | 10 | 0.929 | 0.999 | 1.016 | 1.142 |
| 1 | 1048576 | get | 10 | 0.493 | 0.503 | 0.504 | 2.189 |
| 1 | 16777216 | put | 10 | 1.122 | 1.237 | 1.238 | 14.218 |
| 1 | 16777216 | get | 10 | 0.503 | 0.597 | 0.607 | 31.617 |
| 1 | 67108864 | put | 10 | 1.593 | 1.845 | 1.914 | 38.358 |
| 1 | 67108864 | get | 10 | 0.908 | 1.063 | 1.085 | 68.039 |
| 2 | 65536 | put | 10 | 0.510 | 0.851 | 0.878 | 0.102 |
| 2 | 65536 | get | 10 | 0.283 | 0.385 | 0.417 | 0.205 |
| 2 | 1048576 | put | 10 | 0.533 | 1.034 | 1.074 | 1.527 |
| 2 | 1048576 | get | 10 | 0.311 | 0.482 | 0.504 | 2.857 |
| 2 | 16777216 | put | 10 | 1.314 | 1.567 | 1.579 | 11.938 |
| 2 | 16777216 | get | 10 | 1.066 | 1.109 | 1.122 | 15.172 |
| 2 | 67108864 | put | 10 | 2.780 | 2.985 | 3.020 | 22.327 |
| 2 | 67108864 | get | 10 | 2.994 | 3.095 | 3.117 | 21.055 |
| 3 | 65536 | put | 10 | 0.721 | 0.832 | 0.858 | 0.088 |
| 3 | 65536 | get | 10 | 0.400 | 0.442 | 0.460 | 0.163 |
| 3 | 1048576 | put | 10 | 0.582 | 0.811 | 0.814 | 1.559 |
| 3 | 1048576 | get | 10 | 0.341 | 0.460 | 0.461 | 2.598 |
| 3 | 16777216 | put | 10 | 1.282 | 1.411 | 1.446 | 12.403 |
| 3 | 16777216 | get | 10 | 0.980 | 1.130 | 1.135 | 15.605 |
| 3 | 67108864 | put | 10 | 2.878 | 3.150 | 3.261 | 21.524 |
| 3 | 67108864 | get | 10 | 3.202 | 3.355 | 3.372 | 19.616 |

Percentiles use linear interpolation across measured API latency samples. Payload GiB/s is successful payload bytes divided by summed API latency, using 2^30 B/GiB; it excludes warmup.

## Evidence and interpretation

The configured NVLink path completed remote memory put/get operations with full payload verification for every requested submission GPU/size/iteration. CUDA pointer attributes establish pinned host source/destination allocations; replica descriptors prove remote memory placement. The native provider's EGM setup validates HOST_NUMA/Fabric support. This establishes this topology's functional path; it does not qualify TRT-LLM end-to-end behavior or peak throughput.

Client error: `none recorded; inspect launcher logs if incomplete`. Cleanup error: `none recorded`.

- [client-results.json](client-results.json): exact setup, package versions, submission GPU identities, pinned host allocation/pointer-type evidence, timestamps, per-iteration `samples` latencies/verified bytes and replica memory endpoints; raw source for this table.
- [client.log](client.log), [provider.log](provider.log), [master.log](master.log): native setup, HOST_NUMA/Fabric allocation and transport errors. Missing files indicate setup did not reach that phase.
- Inventory/configuration artifacts in this logs directory record node topology, GPU Fabric health, NUMA placement, wheel identity and launch controls; inspect these with the failure logs.
- No DSight report or dashboard was collected: byte-transfer correctness and native replica metadata answer this diagnostic's goal without request traces.
- The [slurm-job-sizing skill](https://github.com/NVIDIA/srt-slurm/blob/main/src/srtctl/dsight/skills/slurm-job-sizing/SKILL.md) guided the short two-node allocation and reduced warmup/payload sweep; see the sbatch script for the whole-job budget. No full inference benchmark or campaign skill was used.
- [Mooncake native source at 042ab8a18b0e](https://github.com/kvcache-ai/Mooncake/tree/042ab8a18b0e6ccfe87782261a5556a3dd4446e4): `mooncake-integration/store/store_py.cpp` supplies the native APIs; `mooncake-transfer-engine/src/transport/nvlink_transport/nvlink_transport.cpp` accepts local host endpoints and copies directly to/from imported Fabric mappings. The descriptor API exposes a memory endpoint, not a transport-protocol or HOST_NUMA field; the transport/EGM evidence comes from strict native setup and logs.
- [CUDA Python 13.0.1 pointer-attribute API](https://nvidia.github.io/cuda-python/cuda-bindings/13.0.1/module/runtime.html#cuda.bindings.runtime.cudaPointerGetAttributes) defines the status/attributes return pair and `cudaMemoryTypeHost` used to verify payload residence.

Batch exit code: 0.
