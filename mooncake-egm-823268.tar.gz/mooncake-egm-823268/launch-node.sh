#!/bin/bash
set -euo pipefail
run_dir=${1:?Run directory is required}
rank=${SLURM_PROCID:?Missing Slurm task rank}
master_pid= provider_pid=

stop_child() {
    local pid=$1 label=$2 deadline child_rc=0
    [[ -n $pid ]] || return 0
    kill -TERM "$pid" 2>/dev/null || true
    deadline=$((SECONDS + 20))
    while kill -0 "$pid" 2>/dev/null && (( SECONDS < deadline )); do sleep 1; done
    if kill -0 "$pid" 2>/dev/null; then
        printf '%s did not stop within 20 seconds; killing owned PID %s.\n' "$label" "$pid" >&2
        kill -KILL "$pid" 2>/dev/null || true
        cleanup_failed=1
    fi
    wait "$pid" 2>/dev/null || child_rc=$?
    if (( child_rc != 0 )) && [[ $label == provider || $child_rc != 143 ]]; then
        printf '%s exited with code %s during shutdown.\n' "$label" "$child_rc" >&2
        cleanup_failed=1
    fi
}
cleanup() {
    local rc=$?
    trap - EXIT
    trap '' INT TERM
    set +e
    cleanup_failed=0
    stop_child "$provider_pid" provider
    stop_child "$master_pid" master
    if (( cleanup_failed != 0 && rc == 0 )); then rc=1; fi
    printf 'rank=%s exit_code=%s cleanup_failed=%s\n' "$rank" "$rc" "$cleanup_failed" \
        > "$run_dir/logs/shutdown-$rank.txt"
    exit "$rc"
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM

# These are Store clients, not TRT-LLM/MPI workers. Keep all four node GPUs
# visible so provider auto discovery includes both host NUMA nodes.
for name in $(compgen -e); do
    case "$name" in PMIX_*|PMI_*|OMPI_*|MPI_*|OPAL_*|PRTE_*|HYDRA_*|I_MPI_*) unset "$name" ;; esac
done
unset MC_USE_NVLINK_IPC MC_TE_FILTERS MC_ENABLE_DEST_DEVICE_AFFINITY MC_FORCE_TCP
export CUDA_VISIBLE_DEVICES=0,1,2,3
export MC_MS_AUTO_DISC=0 MC_USE_TENT=0 MC_USE_TEV1=0 MOONCAKE_STORE_BACKEND=cpp
export GLOG_logtostderr=1 GLOG_minloglevel=0 GLOG_v=0 PYTHONUNBUFFERED=1
export PIP_NO_INDEX=1 PIP_DISABLE_PIP_VERSION_CHECK=1
export SRT_MOONCAKE_EGM_WHEEL_DIR=/egm-wheels
export PYTHONPATH="$run_dir${PYTHONPATH:+:$PYTHONPATH}"

timeout --signal=TERM --kill-after=10s "${MC_EGM_SETUP_TIMEOUT}s" \
    bash "$run_dir/configs/setup_mooncake_egm.sh" --mooncake-only \
    > "$run_dir/logs/setup-$rank.log" 2>&1

{
    hostname
    nvidia-smi --query-gpu=index,uuid,pci.bus_id,name,memory.total,driver_version --format=csv
    nvidia-smi topo -m
    nvidia-smi -q -d FABRIC || true
    ls -l /dev/nvidia-caps-imex-channels/ || true
    command -v numactl >/dev/null && numactl --hardware || true
} > "$run_dir/logs/inventory-$rank.txt" 2>&1

if [[ $rank == 0 ]]; then
    # Allocate two currently unused master listeners on this exclusive node.
    python3 - "$run_dir" <<'PY'
import json
import os
import socket
import sys
from contextlib import ExitStack
from pathlib import Path

run_dir = Path(sys.argv[1])
with ExitStack() as stack:
    listeners = [stack.enter_context(socket.socket()) for _ in range(2)]
    for listener in listeners:
        listener.bind(("0.0.0.0", 0))
    rpc, metrics = [listener.getsockname()[1] for listener in listeners]
hostname = socket.gethostname()
config = {"master_server_address": f"{socket.gethostbyname(hostname)}:{rpc}",
          "provider_hostname": hostname, "metrics_port": metrics}
temporary = run_dir / ".master-config.tmp"
temporary.write_text(json.dumps(config, indent=2) + "\n")
os.replace(temporary, run_dir / "master-config.json")
(run_dir / "master-ports").write_text(f"{rpc} {metrics}\n")
PY
    read -r master_port metrics_port < "$run_dir/master-ports"
    python3 -m mooncake.cli --rpc_port="$master_port" --metrics_port="$metrics_port" \
        --default_kv_lease_ttl=60000 --eviction_ratio=0.02 \
        > "$run_dir/logs/master.log" 2>&1 &
    master_pid=$!
    # Wait for the actual RPC listener rather than publishing premature readiness.
    python3 - "$master_port" "$MC_EGM_READY_TIMEOUT" <<'PY'
import socket
import sys
import time

deadline = time.monotonic() + int(sys.argv[2])
while time.monotonic() < deadline:
    try:
        with socket.create_connection(("127.0.0.1", int(sys.argv[1])), timeout=1):
            break
    except OSError:
        time.sleep(0.25)
else:
    raise SystemExit("Mooncake master RPC readiness timed out; see logs/master.log")
PY
    kill -0 "$master_pid"
    python3 "$run_dir/configs/mooncake_egm_donor.py" serve \
        --config "$run_dir/master-config.json" --segment-size "$MC_EGM_POOL_SIZE" \
        --numa-nodes auto --ready-file "$run_dir/logs/provider.ready.json" \
        > "$run_dir/logs/provider.log" 2>&1 &
    provider_pid=$!
    deadline=$((SECONDS + MC_EGM_READY_TIMEOUT))
    while [[ ! -f $run_dir/logs/provider.ready.json ]]; do
        kill -0 "$master_pid"
        kill -0 "$provider_pid"
        if (( SECONDS >= deadline )); then
            printf 'EGM provider readiness timed out; see logs/provider.log.\n' >&2
            exit 1
        fi
        sleep 1
    done
    cp "$run_dir/logs/provider.ready.json" "$run_dir/logs/provider-config.json"
    deadline=$((SECONDS + MC_EGM_SETUP_TIMEOUT + MC_EGM_CLIENT_TIMEOUT + MC_EGM_READY_TIMEOUT))
    while [[ ! -f $run_dir/client.done ]]; do
        kill -0 "$master_pid"
        kill -0 "$provider_pid"
        if (( SECONDS >= deadline )); then
            printf 'Client completion timed out; see rank-1 and client logs.\n' >&2
            exit 1
        fi
        sleep 1
    done
elif [[ $rank == 1 ]]; then
    deadline=$((SECONDS + MC_EGM_SETUP_TIMEOUT + 2 * MC_EGM_READY_TIMEOUT))
    while [[ ! -f $run_dir/logs/provider.ready.json ]]; do
        if (( SECONDS >= deadline )); then
            printf 'Remote provider readiness timed out; see rank-0 logs.\n' >&2
            exit 1
        fi
        sleep 1
    done
    read -r master_address provider_hostname < <(python3 - "$run_dir/master-config.json" <<'PY'
import json
import sys

with open(sys.argv[1]) as stream:
    config = json.load(stream)
print(config["master_server_address"], config["provider_hostname"])
PY
    )
    timeout --signal=TERM --kill-after=10s "${MC_EGM_CLIENT_TIMEOUT}s" \
        python3 "$run_dir/tools/check_mooncake_egm.py" client \
        --master "$master_address" --provider-hostname "$provider_hostname" \
        --run-dir "$run_dir" --gpu-ids "$MC_EGM_GPU_IDS" --sizes "$MC_EGM_SIZES" \
        --iterations "$MC_EGM_ITERATIONS" --warmup "$MC_EGM_WARMUP" \
        > "$run_dir/logs/client.log" 2>&1
    if ! grep -Fq 'NvlinkTransport: using cudaMemcpyBatchAsync' "$run_dir/logs/client.log"; then
        printf 'Missing actual NVLink transfer evidence in logs/client.log.\n' >&2
        exit 1
    fi
    touch "$run_dir/client.done"
else
    printf 'Unexpected Slurm rank: %s\n' "$rank" >&2
    exit 2
fi
