# Mooncake remote EGM diagnostic

Host-transfer status: **FAIL / INCOMPLETE**; launcher exit code: `143`.
Allocation diagnostic status: **INCOMPLETE**. A small-pool transfer pass does not validate recipe-sized pool allocation; see the independent allocation cases below.
Native NVLink memcpy log observed: `False` (source: `client.log`).
Requested verified samples complete: `False` (source: `client-results.json`).
Pinned host source/destination buffers verified: `False` (source: `client-results.json` CUDA pointer attributes).
Report generated: 2026-10-22T15:44:32.883583+00:00.

## Goal and controls

Test whether pinned host buffers can put/get and fully verify data in the other node's EGM host-memory Store pool using the explicitly selected Mooncake NVLink transport. The client owns zero global Store capacity and zero internal Store local-buffer capacity. Each returned replica must be COMPLETE memory on the provider node. Both client payload buffers are pinned CPU tensors and must have CUDA pointer type `cudaMemoryTypeHost`; managed and GPU payload buffers are rejected. GPU IDs select CUDA submission devices only. CUDA contexts, streams and mapping metadata may still use GPU resources; this test does not require zero driver/context HBM consumption.

Baseline: none; this reduced correctness diagnostic does not compare transports or enforce a bandwidth SLO. The small payload sweep measures synchronous API latency, including RPC/control overhead; it does not measure NVLink saturation. No RDMA/TCP data transport is requested. TCP control-plane RPC is still used.

## Configuration and hardware

- Slurm job: `5623`; two allocated nodes.
- Client: `not reached`; provider: `see provider/inventory logs`.
- CUDA submission GPU IDs/names: `[]` / `{}`.
- Payload allocation: `unverified`; verified buffer records: `0` / `0`.
- PyTorch/CUDA: `unavailable` / `unavailable`; wheel packages: `{}`.
- Payload sizes (B): `[]`; concurrency: one synchronous transfer; warmup/measurement iterations per GPU/size: `unknown` / `unknown`.
- Client window UTC: `not reached` to `incomplete`; wall duration: `unavailable` s.

## Host-memory allocation diagnostics

Allocation diagnostic status: **INCOMPLETE**; collection status: `stopped_unsafe_cleanup`; provider: `vr-r41-cn01`; CUDA visible devices: `0` (source: [summary.json](allocation-diagnostics/summary.json)).

These probes test native host NUMA/Fabric Store setup and cleanup separately from remote put/get. Their outcomes do not change the remote-transfer status above. CUDA error 2 identifies an allocation or resource failure; it does not identify the limiting resource or establish that GPU payload memory was allocated. Compare host/NUMA availability, cgroup limits and CUDA discovery in the inventory with each case's configuration and errors. Sequential pool successes do not prove that four concurrent pools and inference workers fit.

- [Allocation inventory](allocation-diagnostics/inventory.json): host/NUMA, cgroup and CUDA evidence.

| GPU mask | NUMA nodes | Pool GiB | Case status | Exit code | CUDA errors | Cleanup confirmed | Evidence |
| --- | --- | ---: | --- | --- | --- | --- | --- |
| 0 | 0 | 4 | child_failed | 1 | none recorded | False | [log](allocation-diagnostics/4294967296-numa-0.log); [result](allocation-diagnostics/4294967296-numa-0.json) |

The per-case JSON records native setup/close results, elapsed setup/cleanup time and before/after inventory when available. Missing case results or timeout/cleanup failures leave allocation capacity unproven; they do not by themselves identify the cause. These timings measure allocation probes, not transfer latency or model performance.

## Measurements

TTFT p50/p95/p99 (ms), ITL p50/p99 (ms/token), input/output/total throughput (tokens/s), and agentic Pareto/SLO metrics: **N/A**. This workload transfers bytes and runs no inference requests, model, tokenizer or agentic conversations.

Fully verified transfers: 0 put/get pairs including warmup; 0 measured pairs. Every successful sample compares the complete CPU destination with the deterministic CPU source. Payload generation and equality verification are outside timed intervals.

Transfer latency and byte throughput: unavailable; no measured successful sample was preserved.

## Evidence and interpretation

This run did not establish that all requested remote EGM transfers work. Inspect the failure and native provider/client logs before changing allocator, driver, topology or wheel configuration. Any preserved measurements describe completed cases only.

Client error: `none recorded; inspect launcher logs if incomplete`. Cleanup error: `none recorded`.

- [client-results.json](client-results.json): exact setup, package versions, submission GPU identities, pinned host allocation/pointer-type evidence, timestamps, per-iteration `samples` latencies/verified bytes and replica memory endpoints; raw source for this table.
- [client.log](client.log), [provider.log](provider.log), [master.log](master.log): native setup, HOST_NUMA/Fabric allocation and transport errors. Missing files indicate setup did not reach that phase.
- Inventory/configuration artifacts in this logs directory record node topology, GPU Fabric health, NUMA placement, wheel identity and launch controls; inspect these with the failure logs.
- No DSight report or dashboard was collected: byte-transfer correctness and native replica metadata answer this diagnostic's goal without request traces.
- The [slurm-job-sizing skill](https://github.com/NVIDIA/srt-slurm/blob/main/src/srtctl/dsight/skills/slurm-job-sizing/SKILL.md) guided the short two-node allocation and reduced warmup/payload sweep; see the sbatch script for the whole-job budget. No full inference benchmark or campaign skill was used.
- [Mooncake native source at 042ab8a18b0e](https://github.com/kvcache-ai/Mooncake/tree/042ab8a18b0e6ccfe87782261a5556a3dd4446e4): `mooncake-integration/store/store_py.cpp` supplies the native APIs; `mooncake-transfer-engine/src/transport/nvlink_transport/nvlink_transport.cpp` accepts local host endpoints and copies directly to/from imported Fabric mappings. The descriptor API exposes a memory endpoint, not a transport-protocol or HOST_NUMA field; the transport/EGM evidence comes from strict native setup and logs.
- [CUDA Python 13.0.1 pointer-attribute API](https://nvidia.github.io/cuda-python/cuda-bindings/13.0.1/module/runtime.html#cuda.bindings.runtime.cudaPointerGetAttributes) defines the status/attributes return pair and `cudaMemoryTypeHost` used to verify payload residence.

Batch exit code: 143.
